package com.cg.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationBean {

	@FindBy(how=How.ID,id="reg-firstname")
	private WebElement firstName;
	@FindBy(how=How.ID,id="reg-lastname")
	private WebElement lastName;
	@FindBy(how=How.ID,id="reg-email")
	private WebElement email;
	@FindBy(how=How.ID,id="reg-password")
	private WebElement password;
	@FindBy(how=How.ID,id="registration-submit")
	private WebElement submit;
	
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return lastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public String getEmail() {
		return email.getAttribute("value");
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public String getPassword() {
		return password.getAttribute("value");
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	
	public void nextClick() {
		submit.click();
	}
}
