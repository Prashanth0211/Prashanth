package com.cg.step;

import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.pojo.RegistrationBean;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStep {

	DriverUtil util = new DriverUtil();
	private WebDriver driver;
	private RegistrationBean bean;

	@Before
	public void setUp() throws Exception {
		driver = util.initiateDriver("chrome");
		bean = new RegistrationBean();
		PageFactory.initElements(driver, bean);
	}

	@After
	public void tearDown() throws Exception {
		util.closeDriver(driver);
	}

	@Test
	public void test() throws Throwable {
		i_open_linkedin_site();
		i_enter_Fields_correctly_and_click_on_join_now_link();
		registered_successfully();
	}

	@Given("^I open linkedin site$")
	public void i_open_linkedin_site() throws Throwable {
		driver.get("https://www.linkedin.com");
	}

	@When("^I enter Fields correctly and click on join now link$")
	public void i_enter_Fields_correctly_and_click_on_join_now_link() throws Throwable {

		bean.setFirstName("Nichenametla");
		bean.setLastName("Prashanth");
		bean.setEmail("prashanthpsn1995@gmail.com");
		bean.setPassword("9441742260");

	}

	@Then("^Registered successfully$")
	public void registered_successfully() throws Throwable {
		bean.nextClick();
		String title=driver.getTitle();
	    assertEquals("LinkedIn: Log In or Sign Up", title);
	}
}
