package com.cg.step;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.pojo.ConferenceBookingBean;
import com.cg.util.DriverUtil;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceStep {
	DriverUtil util = new DriverUtil();
	private WebDriver driver;
	private ConferenceBookingBean bean;

	@Before
	public void setUp() throws Exception {
		driver = util.initiateDriver("chrome");
		bean = new ConferenceBookingBean();
		PageFactory.initElements(driver, bean);
	}

	@After
	public void tearDown() throws Exception {
		util.closeDriver(driver);

	}

	@Test
	public void test() throws Throwable {
		user_is_on_Conference_Room_Booking_Login_Page();
		user_click_on_next_link_without_entering_First_Name();
		please_Fill_First_Name_message_should_display();
		user_click_on_next_link_without_entering_Last_Name();
		please_Fill_Last_Name_message_should_display();
		user_click_on_next_link_without_entering_email();
		please_Fill_email_message_should_display();
		user_select_next_link_after_entering_invalid_email_address();
		please_enter_valid_Email_Id_message_should_display();
		user_click_on_next_link_without_entering_contact_number();
		please_Fill_Contact_Number_message_should_display();
		user_select_next_link_after_entering_invalid_Contact_No();
		please_enter_valid_Contact_no_message_should_display();
		user_click_on_next_link_without_selecting_city();
		please_Select_City_message_should_display();
		user_click_on_next_link_without_selecting_state();
		please_Select_State_message_should_display();
		user_click_on_next_link_without_entering_number_of_people_attending();
		please_Fill_number_of_people_attending_message_should_display();
		user_click_on_next_link_without_entering_card_holder_name();
		please_Fill_Card_Holder_Name_message_should_display();
		user_click_on_next_link_without_entering_card_number();
		please_Fill_Card_Number_message_should_display();
		user_click_on_next_link_without_entering_cvv();
		please_Fill_CVV_message_should_display();
		user_click_on_next_link_without_entering_expiry_month();
		please_Fill_Expiry_Month_message_should_display();
		user_click_on_next_link_without_entering_expiry_year();
		please_Fill_Expiry_Year_message_should_display();
		user_click_on_next_link_with_entering_valid_information();
		personal_Details_Are_Validated_message_should_display();
	}

	@Given("^User is on Conference Room Booking Login Page$")
	public void user_is_on_Conference_Room_Booking_Login_Page() throws Throwable {
		driver.get("D:\\BDDSeleniumPOM\\ConferenceBooking\\ConferenceBooking\\WebContent\\hotelbooking.html");
	}

	@When("^User click on 'next' link without entering First Name$")
	public void user_click_on_next_link_without_entering_First_Name() throws Throwable {
		bean.nextClick();
	}

	@Then("^'Please Fill First Name' message should display$")
	public void please_Fill_First_Name_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the First Name";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering Last Name$")
	public void user_click_on_next_link_without_entering_Last_Name() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setFirstName("Prashanth");
		bean.nextClick();
	}

	@Then("^'Please Fill Last Name' message should display$")
	public void please_Fill_Last_Name_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Last Name";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering email$")
	public void user_click_on_next_link_without_entering_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setLastName("Psn");
		bean.nextClick();
	}

	@Then("^'Please Fill email' message should display$")
	public void please_Fill_email_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Email";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'next' link after entering invalid email address$")
	public void user_select_next_link_after_entering_invalid_email_address() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setEmail("psngmail.com");
		bean.nextClick();
	}

	@Then("^'Please enter valid Email Id' message should display$")
	public void please_enter_valid_Email_Id_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please enter valid Email Id.";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering contact number$")
	public void user_click_on_next_link_without_entering_contact_number() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.findElement(By.id("txtEmail")).clear();
		bean.setEmail("prashanthpsn1995@gmail.com");
		bean.nextClick();
	}

	@Then("^'Please Fill Contact Number' message should display$")
	public void please_Fill_Contact_Number_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Mobile No.";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'next' link after entering invalid Contact No$")
	public void user_select_next_link_after_entering_invalid_Contact_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setPhone("123456789");
		bean.nextClick();
	}

	@Then("^'Please enter valid Contact no' message should display$")
	public void please_enter_valid_Contact_no_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please enter valid Contact no.";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without selecting city$")
	public void user_click_on_next_link_without_selecting_city() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.findElement(By.id("txtPhone")).clear();
		bean.setPhone("7660824282");
		bean.setAddress("Gachibowli");
		bean.nextClick();
	}

	/*
	 * @When("^User click on 'next' link without selecting city$") public void
	 * user_click_on_next_link_without_selecting_city() throws Throwable {
	 * bean.setAddress("Gachibowli"); bean.nextClick(); }
	 */

	@Then("^'Please Select City' message should display$")
	public void please_Select_City_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please select city";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without selecting state$")
	public void user_click_on_next_link_without_selecting_state() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setCity("Hyderabad");
		;
		bean.nextClick();
	}

	@Then("^'Please Select State' message should display$")
	public void please_Select_State_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please select state";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering number of people attending$")
	public void user_click_on_next_link_without_entering_number_of_people_attending() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setState("Telangana");
		;
		bean.nextClick();
	}

	@Then("^'Please Fill number of people attending' message should display$")
	public void please_Fill_number_of_people_attending_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Number of people attending";
		// assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering card holder name$")
	public void user_click_on_next_link_without_entering_card_holder_name() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setPeople("4");
		;
		bean.nextClick();
	}

	@Then("^'Please Fill Card Holder Name' message should display$")
	public void please_Fill_Card_Holder_Name_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Card holder name";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering card number$")
	public void user_click_on_next_link_without_entering_card_number() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setCardholder("Nichenametla");
		;
		bean.nextClick();
	}

	@Then("^'Please Fill Card Number' message should display$")
	public void please_Fill_Card_Number_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Debit card Number";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering cvv$")
	public void user_click_on_next_link_without_entering_cvv() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setCardnumber("123456789123");
		;
		bean.nextClick();
	}

	@Then("^'Please Fill CVV' message should display$")
	public void please_Fill_CVV_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the CVV";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering expiry month$")
	public void user_click_on_next_link_without_entering_expiry_month() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setCvv("100");
		;
		bean.nextClick();
	}

	@Then("^'Please Fill Expiry Month' message should display$")
	public void please_Fill_Expiry_Month_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill expiration month";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link without entering expiry year$")
	public void user_click_on_next_link_without_entering_expiry_year() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setExpirymonth("07");
		;
		bean.nextClick();
	}

	@Then("^'Please Fill Expiry Year' message should display$")
	public void please_Fill_Expiry_Year_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the expiration year";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'next' link with entering valid information$")
	public void user_click_on_next_link_with_entering_valid_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setExpiryyear("2023");

	}

	@Then("^'Personal Details Are Validated' message should display$")
	public void personal_Details_Are_Validated_message_should_display() throws Throwable {
		bean.nextClick();
	}

}
