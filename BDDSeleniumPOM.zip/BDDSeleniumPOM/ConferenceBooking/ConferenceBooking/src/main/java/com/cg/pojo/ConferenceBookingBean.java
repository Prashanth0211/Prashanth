package com.cg.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class ConferenceBookingBean {

	@FindBy(how = How.ID, id = "txtFirstName")
	private WebElement firstName;
	@FindBy(how = How.ID, id = "txtLastName")
	private WebElement lastName;
	@FindBy(how = How.ID, id = "txtEmail")
	private WebElement email;
	@FindBy(how = How.ID, id = "txtPhone")
	private WebElement phone;
	@FindBy(how = How.ID, id = "address")
	private WebElement address;
	@FindBy(how = How.NAME, name = "city")
	private WebElement city;
	@FindBy(how = How.NAME, name = "state")
	private WebElement state;
	@FindBy(how = How.NAME, name = "persons")
	private WebElement people;
	@FindBy(how = How.ID, id = "txtCardholderName")
	private WebElement cardholder;
	@FindBy(how = How.ID, id = "txtDebit")
	private WebElement cardnumber;
	@FindBy(how = How.ID, id = "txtCvv")
	private WebElement cvv;
	@FindBy(how = How.ID, id = "txtMonth")
	private WebElement expirymonth;
	@FindBy(how = How.ID, id = "txtYear")
	private WebElement expiryyear;

	@FindBy(how = How.ID, id = "btnPayment")
	private WebElement next;

	public void nextClick() {
		next.click();
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
		;
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
		;
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhone() {
		return phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public int getPeople() {
		return Integer.parseInt(new Select(people).getFirstSelectedOption().getText());
	}

	public void setPeople(String people) {
		new Select(this.people).selectByVisibleText(people);
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return new Select(city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}
	public String getState() {
		return new Select(state).getFirstSelectedOption().getText();
	}
	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}

	public String getCardholder() {
		return cardholder.getAttribute("value");
	}

	public void setCardholder(String cardholder) {
		this.cardholder.sendKeys(cardholder);;
	}

	public String getCardnumber() {
		return cardnumber.getAttribute("value");
	}

	public void setCardnumber(String cardnumber) {
		this.cardnumber.sendKeys(cardnumber);;
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);;
	}

	public String getExpirymonth() {
		return expirymonth.getAttribute("value");
	}

	public void setExpirymonth(String expirymonth) {
		this.expirymonth.sendKeys(expirymonth);
	}

	public String getExpiryyear() {
		return expiryyear.getAttribute("value");
	}

	public void setExpiryyear(String expiryyear) {
		this.expiryyear.sendKeys(expiryyear);;
	}
}
