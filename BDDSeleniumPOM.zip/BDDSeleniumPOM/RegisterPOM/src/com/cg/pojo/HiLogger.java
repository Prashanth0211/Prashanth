package com.cg.pojo;

import org.apache.log4j.Logger;

public class HiLogger {

	public static void main(String[] args) {
		
		Logger log = Logger.getLogger(HiLogger.class);
		log.info("hjsdfsdvhjsdfsdf");
		log.debug("Prashanth");
	}

}
