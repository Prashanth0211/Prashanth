package com.cg.pojo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegisterBean {

	@FindBy(how = How.ID, id = "txtFN")
	private WebElement userName;
	@FindBy(how = How.NAME, name = "rdDesignation")
	private List<WebElement> designation;
	@FindBy(how = How.ID, id = "ddlCountry")
	private WebElement country;
	@FindBy(how = How.ID, id="btnSubmit")
	private WebElement nextLink;
	@FindBy(how = How.ID, id = "btnReset")
	private WebElement resetLink;

	public String getUserName() {
		return userName.getAttribute("value");
	}

	public void setUserName(String userName) {

		this.userName.sendKeys(userName);
	}

	public String getDesignation() {
		return ((WebElement) designation).getAttribute("value");
	}

	public void setDesignation(String designation) {
		if(designation.equals("SE")) {		
			this.designation.get(0).click();
		}
		else if(designation.equals("SSE"))  {
			this.designation.get(1).click();
		}
		
	}

	public String getCountry() {
		return new Select(this.country).getFirstSelectedOption().getText();
	}

	public void setCountry(String country) {

		new Select(this.country).selectByVisibleText(country);
		/*Select select = new Select(this.country.findElement(By.id("ddlCountry")));
		select.selectByValue(country);*/
	}

	public void clickSubmit() {
		nextLink.click();
	}

	public void clickReset() {
		resetLink.click();
	}
}
