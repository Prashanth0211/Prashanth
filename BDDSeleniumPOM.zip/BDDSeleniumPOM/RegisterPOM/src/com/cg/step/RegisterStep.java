package com.cg.step;

import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.pojo.RegisterBean;
import com.cg.util.DriverUtil;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterStep {

	DriverUtil util = new DriverUtil();
	private WebDriver driver;
	private RegisterBean pagebean;

	@Before
	public void setUp() throws Exception {
		driver = util.initiateDriver("chrome");
		pagebean=new RegisterBean();
		PageFactory.initElements(driver, pagebean);
	}

	@After
	public void tearDown() throws Exception {
	
		util.closeDriver(driver);
	}

	@Test
	public void test() throws Throwable{
		i_open_login_page();
		i_fill_required_details_and_click_on_next_link();
		return_to_new_page();
		
	}

	@Given("^I open login page$")
	public void i_open_login_page() throws Throwable {

		driver.get("http://localhost:9095/RegisterPOM/index.html");
		
	}

	@When("^I fill required details and click on next link$")
	public void i_fill_required_details_and_click_on_next_link() throws Throwable {
		pagebean.setUserName("Prashanth");
		pagebean.setDesignation("SSE");
		pagebean.setCountry("Hindustan");
		
		
	}
	@Then("^return to new page$")
	public void return_to_new_page() throws Throwable {
		/*String title=driver.getTitle();
		assertEquals("Details", title);*/
		pagebean.clickSubmit();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		pagebean.clickReset();
		}
	
	

	
}
