package com.cg.registrationform.step;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.registrationform.pojo.RegistrationFormBean;
import com.cg.registrationform.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationFormStep {

	DriverUtil util = new DriverUtil();
	private WebDriver driver;
	private RegistrationFormBean bean;

	@Before
	public void setUp() throws Exception {
		driver = util.initiateDriver("chrome");
		bean = new RegistrationFormBean();
		PageFactory.initElements(driver, bean);
	}

	@After
	public void tearDown() throws Exception {
		util.closeDriver(driver);
	}

	@Test
	public void test() throws Throwable {
		user_is_on_Registration_Form_Page();
		user_click_on_Next_link_without_filling_First_Name();
		please_Fill_the_First_Name_message_should_display();
		user_click_on_Next_link_without_filling_Last_Name();
		please_Fill_the_Last_Name_message_should_display();
		user_click_on_Next_link_without_filling_email();
		please_Fill_the_email_message_should_display();
		user_select_Next_link_after_filling_invalid_email_address();
		please_enter_the_valid_Email_Id_message_should_display();
		user_click_on_Next_link_without_filling_contact_number();
		please_Fill_the_Contact_Number_message_should_display();
		user_select_Next_link_after_filling_invalid_Contact_No();
		please_enter_the_valid_Contact_no_message_should_display();
		user_select_Next_link_after_filling_invalid_address_line_one();
		please_enter_the_valid_Address_line_one_message_should_display();
		user_select_Next_link_after_filling_invalid_address_line_two();
		please_enter_the_valid_Address_line_two_message_should_display();
		user_click_on_Next_link_without_selecting_the_city();
		please_Select_the_City_message_should_display();
		user_click_on_Next_link_without_selecting_the_state();
		please_Select_the_State_message_should_display();
		user_click_on_Next_link_with_filling_valid_set_of_information();
		personal_Details_are_Validated_message_should_display();
		user_click_on_Register_Me_link_without_selecting_the_graduation();
		please_Select_the_Graduation_message_should_display();
		user_click_on_Register_Me_link_without_filling_Percentage();
		please_Fill_Percentage_message_should_display();
		user_click_on_Register_Me_link_without_filling_pass_year();
		please_Fill_Pass_Year_message_should_display();
		user_click_on_Register_Me_link_without_filling_project_name();
		please_Fill_Project_Name_message_should_display();
		user_click_on_Register_Me_link_without_selecting_Technologies();
		please_Select_Technologies_message_should_display();
		user_click_on_Register_Me_link_without_selecting_other_Technologies();
		please_Select_Other_Technologies_message_should_display();
		user_click_on_Register_Me_link_with_providing_valid_set_of_information();
		registered_Successfully_message_should_display();
	}

	@Given("^User is on Registration Form Page$")
	public void user_is_on_Registration_Form_Page() throws Throwable {
		driver.get("D:\\BDDSeleniumPOM\\RegistrationForm\\WebContent\\PersonalDetails.html");
	}

	@When("^User click on 'Next' link without filling First Name$")
	public void user_click_on_Next_link_without_filling_First_Name() throws Throwable {
		if (driver.getTitle().equals("Personal Details")) {
			bean.nextClick();
		}
	}

	@Then("^'Please Fill the First Name' message should display$")
	public void please_Fill_the_First_Name_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the First Name";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Next' link without filling Last Name$")
	public void user_click_on_Next_link_without_filling_Last_Name() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setFirstName("Prashanth");
		bean.nextClick();
	}

	@Then("^'Please Fill the Last Name' message should display$")
	public void please_Fill_the_Last_Name_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Last Name";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Next' link without filling email$")
	public void user_click_on_Next_link_without_filling_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setLastName("Nichenamtela");
		bean.nextClick();
	}

	@Then("^'Please Fill the email' message should display$")
	public void please_Fill_the_email_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Email";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link after filling invalid email address$")
	public void user_select_Next_link_after_filling_invalid_email_address() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setEmail("prashanth.com");
		bean.nextClick();
	}

	@Then("^'Please enter the valid Email Id' message should display$")
	public void please_enter_the_valid_Email_Id_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please enter valid Email Id.";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Next' link without filling contact number$")
	public void user_click_on_Next_link_without_filling_contact_number() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.findElement(By.id("txtEmail")).clear();
		bean.setEmail("prashanthpsn1995@gmail.com");
		bean.nextClick();
	}

	@Then("^'Please Fill the Contact Number' message should display$")
	public void please_Fill_the_Contact_Number_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Contact No.";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link after filling invalid Contact No$")
	public void user_select_Next_link_after_filling_invalid_Contact_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setPhone("12345667");
		;
		bean.nextClick();
	}

	@Then("^'Please enter the valid Contact no' message should display$")
	public void please_enter_the_valid_Contact_no_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please enter valid Contact no.";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link after filling invalid address line one$")
	public void user_select_Next_link_after_filling_invalid_address_line_one() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.findElement(By.id("txtPhone")).clear();
		bean.setPhone("7660824282");
		;
		bean.nextClick();
	}

	@Then("^'Please enter the valid Address line one' message should display$")
	public void please_enter_the_valid_Address_line_one_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the address line 1";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User select 'Next' link after filling invalid address line two$")
	public void user_select_Next_link_after_filling_invalid_address_line_two() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setAddressOne("PJRNagar");
		;
		bean.nextClick();
	}

	@Then("^'Please enter the valid Address line two' message should display$")
	public void please_enter_the_valid_Address_line_two_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the address line 2";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Next' link without selecting the city$")
	public void user_click_on_Next_link_without_selecting_the_city() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setAddressTwo("Gachibowli");
		;
		bean.nextClick();
	}

	@Then("^'Please Select the City' message should display$")
	public void please_Select_the_City_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please select city";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Next' link without selecting the state$")
	public void user_click_on_Next_link_without_selecting_the_state() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setCity("Hyderabad");
		bean.nextClick();
	}

	@Then("^'Please Select the State' message should display$")
	public void please_Select_the_State_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please select state";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Next' link with filling valid set of information$")
	public void user_click_on_Next_link_with_filling_valid_set_of_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setState("Telangana");
		bean.nextClick();
	}

	@Then("^'Personal Details are Validated' message should display$")
	public void personal_Details_are_Validated_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Personal details are validated and accepted successfully.";
		assertEquals(expectedMessage, actualMessage);
		Thread.sleep(4000);
		driver.switchTo().alert().accept();
	}

	@When("^User click on 'Register Me' link without selecting the graduation$")
	public void user_click_on_Register_Me_link_without_selecting_the_graduation() throws Throwable {
		if (driver.getTitle().equals("Educational Details")) {
			bean.registerMe();
		}
	}

	@Then("^'Please Select the Graduation' message should display$")
	public void please_Select_the_Graduation_message_should_display() throws Throwable {

		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please Select Graduation";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Register Me' link without filling Percentage$")
	public void user_click_on_Register_Me_link_without_filling_Percentage() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setGraduation("BTech");
		bean.registerMe();
	}

	@Then("^'Please Fill Percentage' message should display$")
	public void please_Fill_Percentage_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill Percentage detail";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Register Me' link without filling pass year$")
	public void user_click_on_Register_Me_link_without_filling_pass_year() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setPercentage("80");
		bean.registerMe();
	}

	@Then("^'Please Fill Pass Year' message should display$")
	public void please_Fill_Pass_Year_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill Passing Year";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Register Me' link without filling project name$")
	public void user_click_on_Register_Me_link_without_filling_project_name() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setPassYear("2018");
		bean.registerMe();
	}

	@Then("^'Please Fill Project Name' message should display$")
	public void please_Fill_Project_Name_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill Project Name";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Register Me' link without selecting Technologies$")
	public void user_click_on_Register_Me_link_without_selecting_Technologies() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setProjectName("ArduinoUNO");
		bean.registerMe();
	}

	@Then("^'Please Select Technologies' message should display$")
	public void please_Select_Technologies_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please Select Technologies Used";
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User click on 'Register Me' link without selecting other Technologies$")
	public void user_click_on_Register_Me_link_without_selecting_other_Technologies() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setTechnologies(".Net");
		bean.setTechnologies("Java");
	}

	@Then("^'Please Select Other Technologies' message should display$")
	public void please_Select_Other_Technologies_message_should_display() throws Throwable {
		bean.registerMe();
	}

	@When("^User click on 'Register Me' link with providing valid set of information$")
	public void user_click_on_Register_Me_link_with_providing_valid_set_of_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setOthertechnologies("Embedded Systems");

	}

	@Then("^'Registered Successfully' message should display$")
	public void registered_Successfully_message_should_display() throws Throwable {
		bean.registerMe();
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		assertEquals(expectedMessage, actualMessage);
		Thread.sleep(4000);
	}
}
