package com.cg.registrationform.pojo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegistrationFormBean {
	@FindBy(how = How.ID, id = "txtFirstName")
	private WebElement firstName;
	@FindBy(how = How.ID, id = "txtLastName")
	private WebElement lastName;
	@FindBy(how = How.ID, id = "txtEmail")
	private WebElement email;
	@FindBy(how = How.ID, id = "txtPhone")
	private WebElement phone;
	@FindBy(how = How.ID, id = "txtAddress1")
	private WebElement addressOne;
	@FindBy(how = How.ID, id = "txtAddress2")
	private WebElement addressTwo;
	@FindBy(how = How.NAME, name = "city")
	private WebElement city;
	@FindBy(how = How.NAME, name = "state")
	private WebElement state;
	@FindBy(how = How.LINK_TEXT, linkText = "Next")
	private WebElement submit;
	@FindBy(how = How.NAME, name = "graduation")
	private WebElement graduation;
	@FindBy(how = How.ID, id = "txtPercentage")
	private WebElement percentage;
	@FindBy(how = How.ID, id = "txtPassYear")
	private WebElement passYear;
	@FindBy(how = How.ID, id = "txtProjectName")
	private WebElement projectName;
	@FindBy(how = How.NAME, name = "technologies")
	private List<WebElement> technologies;
	@FindBy(how = How.NAME, name = "otherTechnologies")
	private WebElement othertechnologies;
	@FindBy(how = How.ID, id = "btnRegister")
	private WebElement registerMe;

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);

	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);

	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);

	}

	public String getPhone() {
		return phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);

	}

	public String getAddressOne() {
		return addressOne.getAttribute("value");
	}

	public void setAddressOne(String addressOne) {
		this.addressOne.sendKeys(addressOne);

	}

	public String getAddressTwo() {
		return addressTwo.getAttribute("value");
	}

	public void setAddressTwo(String addressTwo) {
		this.addressTwo.sendKeys(addressTwo);

	}

	public String getCity() {
		return new Select(city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}

	public String getState() {
		return new Select(state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}

	public String getGraduation() {
		return new Select(graduation).getFirstSelectedOption().getText();
	}

	public void setGraduation(String graduation) {
		new Select(this.graduation).selectByVisibleText(graduation);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);

	}

	public String getPassYear() {
		return passYear.getAttribute("value");
	}

	public void setPassYear(String passYear) {
		this.passYear.sendKeys(passYear);

	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);

	}

	public String getTechnologies() {
		return ((WebElement) technologies).getAttribute("value");
	}

	public void setTechnologies(String technologies) {
		if (technologies.equals(".Net")) {
			this.technologies.get(0).click();
		} else if (technologies.equals("Java")) {
			this.technologies.get(1).click();
		} else if (technologies.equals("PHP")) {
			this.technologies.get(2).click();
		} else if (technologies.equals("Other")) {
			this.technologies.get(3).click();
		}

	}

	public String getOthertechnologies() {
		return othertechnologies.getAttribute("value");
	}

	public void setOthertechnologies(String othertechnologies) {
		this.othertechnologies.sendKeys(othertechnologies);
	}

	public void nextClick() {
		submit.click();
	}

	public void registerMe() {
		registerMe.click();
	}
}
