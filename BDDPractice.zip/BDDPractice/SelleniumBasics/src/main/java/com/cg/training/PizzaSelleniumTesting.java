package com.cg.training;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.cg.training.util.DriverUtil;

public class PizzaSelleniumTesting {

	public static void main(String[] args) {
		DriverUtil util=new DriverUtil();
		WebDriver driver =util.initiateDriver("chrome");
		driver.get("D:\\BDDPractice\\SelleniumBasics\\WebContent\\Pizza.html");
		driver.manage().window().maximize();
		WebElement name=driver.findElement(By.name("name"));
		name.sendKeys("Prashanth");
		driver.findElement(By.id("pizza")).click();
		driver.findElement(By.id("Pizza1")).click();
		driver.findElement(By.id("Pizza2")).click();
		Select select=new Select(driver.findElement(By.id("sel")));
		select.selectByValue("Tomato");
		select.selectByValue("Panner");
		
		driver.findElement(By.name("Pizza")).click();
		WebElement instructions=driver.findElement(By.name("instructions"));
		instructions.sendKeys("Gachibowli");
		WebElement order = driver.findElement(By.name("Order"));
		order.click();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		driver.quit();
	}

}
