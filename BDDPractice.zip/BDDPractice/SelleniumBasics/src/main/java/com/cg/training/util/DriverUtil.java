package com.cg.training.util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class DriverUtil {

	WebDriver driver;
	public WebDriver initiateDriver(String string) {
		if("chrome".equals(string)) {
			System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
			driver=new ChromeDriver();
			return driver;
			}
		return null;
	}
}
