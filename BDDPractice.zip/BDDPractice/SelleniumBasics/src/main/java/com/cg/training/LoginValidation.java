package com.cg.training;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginValidation {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "drivers//chromedriver.exe");
		String baseurl="D:\\JspPractice\\Lab2.1\\WebContent\\index.html";
		WebDriver driver=new ChromeDriver();
		driver.get(baseurl);
		driver.manage().window().maximize();
		WebElement uname = driver.findElement(By.name("txtUsername"));
		uname.sendKeys("Prashanth");
		WebElement pwd = driver.findElement(By.name("pwdPassword"));
		pwd.sendKeys("Prashanth");
		WebElement sub = driver.findElement(By.name("login"));
		sub.click();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//System.out.println("Page title is " + driver.getTitle());
		driver.quit();
		
	}
}
