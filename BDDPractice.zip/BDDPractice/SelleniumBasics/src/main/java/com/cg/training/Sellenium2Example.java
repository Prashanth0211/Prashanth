package com.cg.training;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sellenium2Example {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "drivers//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.amazon.in");
		WebElement element = driver.findElement(By.name("field-keywords"));
		element.sendKeys("laptop");
		element.submit();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//System.out.println("Page title is " + driver.getTitle());
		
		driver.quit();
		
	}

}
