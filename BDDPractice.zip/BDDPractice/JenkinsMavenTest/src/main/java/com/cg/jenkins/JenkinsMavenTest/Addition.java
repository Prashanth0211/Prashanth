package com.cg.jenkins.JenkinsMavenTest;

import static org.junit.Assert.fail;

import org.junit.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Addition {

	@Test
	public void callMe() throws Throwable {
		two_numbers_and();
		we_add_and();
		the_result_is();
	}

	@Test
	public void test() {

	}

	@Given("^two numbers (\\d+) and (\\d+)$")
	public static void two_numbers_and() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Iam in given");
	}

	@When("^we add (\\d+) and (\\d+)$")
	public static void we_add_and() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^the result is (\\d+)$")
	public static void the_result_is() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Iam in then");
	}
}
