package com.cg.jenkins.JenkinsMavenTest;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Bye" );
    }
}
