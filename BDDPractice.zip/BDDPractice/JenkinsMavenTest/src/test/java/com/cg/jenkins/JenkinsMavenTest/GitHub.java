package com.cg.jenkins.JenkinsMavenTest;

import static org.junit.Assert.fail;
import org.junit.Test;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHub {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Given("^User want to create a github account$")
	public void user_want_to_create_a_github_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user clicks on link 'create account' without entering username$")
	public void user_clicks_on_link_create_account_without_entering_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^display login can't be blank$")
	public void display_login_can_t_be_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user clicks on link 'create account' without entering email$")
	public void user_clicks_on_link_create_account_without_entering_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^display email can't be blank$")
	public void display_email_can_t_be_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user clicks on link 'create account' without entering password$")
	public void user_clicks_on_link_create_account_without_entering_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^display password can't be blank$")
	public void display_password_can_t_be_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user clicks on link 'create account' with valid username$")
	public void user_clicks_on_link_create_account_with_valid_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^with valid email$")
	public void with_valid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^with valid password$")
	public void with_valid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^create GitHub account$")
	public void create_GitHub_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
}
