package com.cg.productcart.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productcart.beans.Product;
import com.cg.productcart.exception.IProductException;
import com.cg.productcart.exception.ProductException;
import com.cg.productcart.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	private IProductService service;

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public void createProduct(@RequestBody Product product) {
		service.createProduct(product);
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.PUT)
	public void updateProduct(@RequestBody Product product, @PathVariable String id) {
		service.updateProduct(product, id);
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public void deleteProductById(@PathVariable String id) {
		service.deleteProductById(id);
	}

	@RequestMapping("/products")
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	@RequestMapping("/products/{id}")
	public Product getProductById(@PathVariable String id) {

		return service.getProductById(id);

	}
}
