package com.cg.productcart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productcart.beans.Product;
import com.cg.productcart.exception.IProductException;
import com.cg.productcart.exception.ProductException;
import com.cg.productcart.repo.IProductRepo;

@Service("productservice")
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo repo;

	//------------------------    <ProductCart> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<createProduct>
	 - Input Parameters	:	<product> 
	 - Return Type		:	<Product> 
	 - Author			:	<Prashanth>
	 - Creation Date	:	08/08/2018
	 - Description		:	Creating the Product
	 ********************************************************************************************************/
	@Override
	public void createProduct(Product product) {

		repo.save(product);

	}

	//------------------------    <ProductCart> Application --------------------------
			/*******************************************************************************************************
			 - Method Name	:	<updateProduct>
			 - Input Parameters	:	<product,id> 
			 - Return Type		:	<Product> 
			 - Author			:	<Prashanth>
			 - Creation Date	:	08/08/2018
			 - Description		:	Updating the Product
			 ********************************************************************************************************/
	@Override
	public void updateProduct(Product product, String id) {

		repo.save(product);
	}

	//------------------------    <ProductCart> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	:	<deleteProductById>
		 - Input Parameters	:	<id> 
		 - Return Type		:	<> 
		 - Author			:	<Prashanth>
		 - Creation Date	:	08/08/2018
		 - Description		:	Deleting the Product
		 ********************************************************************************************************/
	@Override
	public void deleteProductById(String id) {

		repo.deleteById(id);
	}

	//------------------------    <ProductCart> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<getAllProducts>
	 - Input Parameters	:	<list> 
	 - Return Type		:	<list> 
	 - Author			:	<Prashanth>
	 - Creation Date	:	08/08/2018
	 - Description		:	Getting Product details
	 ********************************************************************************************************/
	@Override
	public List<Product> getAllProducts() {

		List<Product> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}

	//------------------------    <ProductCart> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	:	<getProductById>
		 - Input Parameters	:	<id> 
		 - Return Type		:	<Product> 
		 - Author			:	<Prashanth>
		 - Creation Date	:	08/08/2018
		 - Description		:	Getting Product details
		 ********************************************************************************************************/
	@Override
	public Product getProductById(String id) {

		return repo.findById(id).get();
	}
}
