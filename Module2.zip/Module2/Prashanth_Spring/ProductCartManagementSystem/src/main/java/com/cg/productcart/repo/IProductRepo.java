package com.cg.productcart.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.productcart.beans.Product;

@Repository("productrepo")
public interface IProductRepo extends CrudRepository<Product, String> {

}
