package com.cg.productcart.exception;

public interface IProductException {

	String ERROR1="Product Not Found ";
}
