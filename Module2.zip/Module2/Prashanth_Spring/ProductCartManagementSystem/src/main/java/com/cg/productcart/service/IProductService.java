package com.cg.productcart.service;

import java.util.List;
import java.util.Optional;

import com.cg.productcart.beans.Product;
import com.cg.productcart.exception.ProductException;

public interface IProductService {

	public void createProduct(Product product);

	public void updateProduct(Product product, String id);

	public void deleteProductById(String id);

	public List<Product> getAllProducts();

	public Product getProductById(String id);

}
