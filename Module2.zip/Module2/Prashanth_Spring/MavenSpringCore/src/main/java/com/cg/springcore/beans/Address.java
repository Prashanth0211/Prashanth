package com.cg.springcore.beans;

import org.springframework.stereotype.Component;

@Component("addr")
public class Address {

	public void print() {
		System.out.println("Address of the Customer");
	}
}
