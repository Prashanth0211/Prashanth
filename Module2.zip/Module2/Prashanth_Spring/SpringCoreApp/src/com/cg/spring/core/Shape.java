package com.cg.spring.core;

public interface Shape {

	public void draw();
}
