package com.cg.spring.core;

public class Triangle implements Shape {

	@Override
	public void draw() {
		System.out.println("Drawing Triangle");
	}
}
