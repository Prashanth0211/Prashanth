package com.cg.bookdata.service;

import java.util.List;
import java.util.Optional;

import com.cg.bookdata.beans.Book;

public interface BookService {

	public void addBook(Book book);

	public void deleteBookById(int id);

	public void updateBook(Book book, int id);

	public List<Book> getAllBooks();
	
	public Optional<Book> getBookById(int id);

}
