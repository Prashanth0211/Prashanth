package com.cg.bookdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.bookdata")
public class BookDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookDataJpaApplication.class, args);
	}
}
