package com.cg.bookdata.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.bookdata.beans.Book;

@Repository("bookrepo")
public interface BookRepo extends CrudRepository<Book, Integer>{

}
