package com.cg.bookdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookDataJpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(BookDataJpa1Application.class, args);
	}
}
