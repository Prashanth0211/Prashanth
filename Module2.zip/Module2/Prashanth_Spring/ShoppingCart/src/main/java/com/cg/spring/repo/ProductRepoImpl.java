package com.cg.spring.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Product;

@Repository("productrepo")
public class ProductRepoImpl implements ProductRepo {

	private static List<Product> list = null;
	static {
		list = new ArrayList<>();
		Product product1 = new Product("110", "Iphone", "Iphone6s", 50000.00);
		Product product2 = new Product("111", "Samsung", "Samsungs9", 60000.00);
		Product product3 = new Product("112", "Redmi", "RedmiNote3", 10000.00);
		Product product4 = new Product("113", "OneplusOne", "Oneplus6", 40000.00);

		list.add(product1);
		list.add(product2);
		list.add(product3);
		list.add(product4);

	}

	@Override
	public List<Product> getAllProducts() {

		return list;
	}

	@Override
	public Product getProductById(String id) {

		for (Product prod : list) {
			if (id.equals(prod.getId())) {
				return prod;
			}
		}
		return null;
	}

	@Override
	public void addProduct(Product product) {
		
		list.add(product);
	}

	@Override
	public void updateProduct(Product product,String id) {
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getId().equals(id)) {
				list.set(i, product);
			}
		}
		
	}

	@Override
	public void deleteProduct(String id) {
		
		for(Product p: list) {
			if(id.equals(p.getId())) {
				list.remove(p);
			}
		}
	}

}
