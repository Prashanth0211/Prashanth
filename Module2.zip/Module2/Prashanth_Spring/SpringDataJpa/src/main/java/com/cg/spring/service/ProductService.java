package com.cg.spring.service;

import java.util.List;
import java.util.Optional;

import com.cg.spring.beans.Product;

public interface ProductService {

	public void addProduct(Product product);

	public void updateProduct(Product product, String id);

	public void deleteProductById(String id);

	public List<Product> getAllProducts();

	public Optional<Product> getProductById(String id);
}
