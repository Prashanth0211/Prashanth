package com.cg.basic;

public class Triangle {

	public void draw() {
		System.out.println("Drawing a triangle");
	}
	Point point=new Point(6, 5);
}
