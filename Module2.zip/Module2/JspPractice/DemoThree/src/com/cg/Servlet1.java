package com.cg;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1.do")
public class Servlet1 extends HttpServlet {
	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String n = request.getParameter("name").trim();
		String m = request.getParameter("mobile").trim();
		String e = request.getParameter("email").trim();
		String u = request.getParameter("username").trim();
		
		HttpSession session=request.getSession(true);
		
		session.setAttribute("name", n);
		session.setAttribute("mobile", m);
		session.setAttribute("email", e);
		session.setAttribute("username", u);
		
		request.getRequestDispatcher("Servlet2").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
