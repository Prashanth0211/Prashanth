package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet {
	PrintWriter out = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		out = response.getWriter();
		HttpSession s1=request.getSession();
		String n = (String)s1.getAttribute("name");
		String m = (String)s1.getAttribute("mobile");
		String e = (String)s1.getAttribute("email");
		String u = (String)s1.getAttribute("username");

		out.println("<h1> Name:" + n + " </h1>");
		out.println("<h1> Mobile:" + m + " </h1>");
		out.println("<h1> Email:" + e + " </h1>");
		out.println("<h1> UserName:" + u + " </h1>");
		out.println("<a href=Servlet3>Servlet3</a>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
