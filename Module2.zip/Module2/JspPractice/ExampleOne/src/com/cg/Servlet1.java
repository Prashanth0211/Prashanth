package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns= {"*.Servlet1"})
public class Servlet1 extends HttpServlet {
	
	PrintWriter out=null;
	public void add() {	
		out.println("<html><head></head><body>");
		out.println("<h1> data is added</h1>");
		out.println("</body></html>");
	}
	public void delete() {	
		out.println("<html><head></head><body>");
		out.println("<h1> data is deleted</h1>");
		out.println("</body></html>");
	}
	public void update() {	
		out.println("<html><head></head><body>");
		out.println("<h1> data is updated</h1>");
		out.println("</body></html>");
	}
	public void edit() {
		out.println("<html><head></head><body>");
		out.println("<h1> data is edited</h1>");
		out.println("</body></html>");
	}
	public void button() {
		LocalDateTime date=LocalDateTime.now();
		out.println("<html><head></head><body>");
		out.println(date);
		out.println("</body></html>");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		out=response.getWriter();
		switch(request.getServletPath()) {
		
		case ("/add.Servlet1"):add();break;
		case ("/delete.Servlet1"):delete();break;
		case ("/update.Servlet1"):update();break;
		case ("/edit.Servlet1"):edit();break;
		case ("/button.Servlet1"):button();break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
