package com.cg;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/user.do")
public class UserDataController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String n = request.getParameter("name").trim();
		String m = request.getParameter("mobile").trim();
		String e = request.getParameter("email").trim();
		String u = request.getParameter("username").trim();
		String g = request.getParameter("gender");
		String courseList[] = request.getParameterValues("course");

		request.setAttribute("name", n);
		request.setAttribute("mobile", m);
		request.setAttribute("email", e);
		request.setAttribute("username", u);
		request.setAttribute("gender", g);
		request.setAttribute("course", courseList);

		RequestDispatcher rd = request.getRequestDispatcher("success.view");
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
