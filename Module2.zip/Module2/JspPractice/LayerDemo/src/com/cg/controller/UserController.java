package com.cg.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Customer;
import com.cg.service.CustomerServiceImpl;
import com.cg.service.ICustomerService;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/store.do")
public class UserController extends HttpServlet {
private ICustomerService serv=null; 
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String name=request.getParameter("userName");
		String fName=request.getParameter("fName");
		String lName=request.getParameter("lName");
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		String interestList[]=request.getParameterValues("intrest");
		//validation
		//successfull validation
		//create obj of pojo
		Customer customer=new Customer(name, fName, lName, email, mobile, interestList);
		serv=new CustomerServiceImpl();
		boolean finalStatus=serv.addCustomer(customer);
		String target=null;
		String msg=null;
		if(finalStatus==true) {
		msg="data is successfully added!!!";
		target="success.jsp";
		}
		else
		{
			msg="data is not added!!!";
			target="index.jsp";
		}
		request.setAttribute("msg", msg);
		request.getRequestDispatcher(target).forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
