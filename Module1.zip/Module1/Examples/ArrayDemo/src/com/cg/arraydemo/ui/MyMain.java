package com.cg.arraydemo.ui;

public class MyMain {

	public static void main(String args[]) {
		
		Employee emp[]=new Employee[3];
		
		emp[0]=new Employee();
		emp[0].setEmpId(1001);
		emp[0].setEmpName("Psn");
		emp[0].setEmpAge(22);

		emp[1]=new Employee();
		emp[1].setEmpId(1002);
		emp[1].setEmpName("nih");
		emp[1].setEmpAge(21);
		
		emp[2]=new Employee();
		emp[2].setEmpId(1003);
		emp[2].setEmpName("rit");
		emp[2].setEmpAge(20);
		
		for(Employee emp1: emp) {
			System.out.println(emp1.getEmpId());
			System.out.println(emp1.getEmpName());
			System.out.println(emp1.getEmpAge());
			
		}
	}
}
