package com.cg;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Example2 {

	public static void main(String[] args) {
		
		FileReader fileReader=null;
		StringBuffer buffer=new StringBuffer();
		try {
			fileReader=new FileReader(new File("D:\\Users\\learning\\Desktop\\ans.txt"));
			int ch;
			while((ch=fileReader.read()) != -1) {
				buffer.append((char)ch);
			}
			fileReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(buffer);
		FileWriter fileWriter=null;
		try {
			fileWriter=new FileWriter(new File("D:\\Users\\learning\\Desktop\\module4_script.txt"));
			fileWriter.write(buffer.toString());
			fileWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
