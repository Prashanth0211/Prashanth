package com.cg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		FileInputStream fileInputStream = null;
		StringBuilder stringBuilder=new StringBuilder();
		try {
			fileInputStream = new FileInputStream(new File("D:\\Users\\learning\\Desktop\\test.txt"));
			int data;
			while ((data = fileInputStream.read()) != -1) {
				stringBuilder.append((char)data);
			}
			fileInputStream.close();
		} catch (FileNotFoundException e) {
			System.out.println("Sorry! File is mising");
		} catch (IOException e) {
			System.out.println("Reading Failed");
		}
		System.out.println(stringBuilder);
		FileOutputStream fileOutputStream=null;
	try {
		fileOutputStream=new FileOutputStream(new File("D:\\Users\\learning\\Desktop\\ans.txt"));
		fileOutputStream.write(stringBuilder.toString().getBytes());
		fileOutputStream.close();
	} catch (FileNotFoundException e) {
		System.out.println("Sorry! File is mising");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		System.out.println("Writing Failed");
	}
	}

}
