package com.cg.examdemo.ui;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
