package com.cg.examdemo.dao;

public class StudentDaoImpl {

}
