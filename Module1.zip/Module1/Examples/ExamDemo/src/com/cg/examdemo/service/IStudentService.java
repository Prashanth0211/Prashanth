package com.cg.examdemo.service;

public interface IStudentService {

}
