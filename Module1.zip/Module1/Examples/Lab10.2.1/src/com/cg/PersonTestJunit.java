package com.cg;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;

import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTestJunit {

	Person person = new Person();

	@BeforeClass
	public static void setUp() throws Exception {
		System.out.println("Testing Starts");
	}

	@AfterClass
	public static void setDown() throws Exception {
		System.out.println("Testing Ends");
	}

	@Test
	public void testFirstName() {
		person.setFname("Prashanth");
		String fname = person.getFname();
		assertEquals("Prashanth", fname);
	}

	@Test
	public void testLastName() {
		person.setFname("Nichenametla");
		String lname = person.getLname();
		assertEquals("Prashanth", lname);
	}

	@Test
	public void testGender() {
		person.setGender('M');
		assertEquals('M', person.getGender());
	}
}
