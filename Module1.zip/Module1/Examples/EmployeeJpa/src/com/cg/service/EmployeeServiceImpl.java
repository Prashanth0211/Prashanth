package com.cg.service;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDao;
import com.cg.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao=new EmployeeDaoImpl();
	@Override
	public void addEmployee(Employee employee) {
		dao.beginTransaction();
		dao.addEmployee(employee);
		dao.commitTransaction();
	}

	@Override
	public boolean validateEmployee(Employee employee) {

		return true;
	}

	@Override
	public Employee searchEmployee(int emId) {
		dao.beginTransaction();
		Employee employee=dao.searchEmployee(emId);
		dao.commitTransaction();
		return employee;
	}

	@Override
	public boolean removeEmployee(int empId) {
	
		boolean result=false;
		dao.beginTransaction();
		Employee employee=dao.searchEmployee(empId);
		if (employee!=null) {
			dao.removeEmployee(employee);
			result=true;
		}
		dao.commitTransaction();
		return result;
	}

	@Override
	public void updateEmployee(Employee employee3) {
		dao.beginTransaction();
		dao.updateEmployee(employee3);
		dao.commitTransaction();
		
	}

}
