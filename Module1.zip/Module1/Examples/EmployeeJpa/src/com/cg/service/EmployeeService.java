package com.cg.service;

import com.cg.bean.Employee;

public interface EmployeeService {

	void addEmployee(Employee employee);

	boolean validateEmployee(Employee employee);

	Employee searchEmployee(int emId);

	boolean removeEmployee(int empId);

	void updateEmployee(Employee employee3);

}
