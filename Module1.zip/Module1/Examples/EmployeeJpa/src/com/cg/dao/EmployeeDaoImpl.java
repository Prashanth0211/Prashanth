package com.cg.dao;

import javax.persistence.EntityManager;


import com.cg.bean.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private EntityManager manager;

	public EmployeeDaoImpl() {
		manager = JPAUtil.getEntityManager();
	}

	@Override
	public void addEmployee(Employee employee) {
		manager.persist(employee);
	}

	@Override
	public Employee searchEmployee(int emId) {
		Employee employee = manager.find(Employee.class, emId);
		return employee;
	}

	@Override
	public void beginTransaction() {
		manager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		manager.getTransaction().commit();
	}

	@Override
	public void removeEmployee(Employee employee) {
		manager.remove(employee);
	}

	@Override
	public void updateEmployee(Employee employee3) {
		
		manager.merge(employee3);
	}

}
