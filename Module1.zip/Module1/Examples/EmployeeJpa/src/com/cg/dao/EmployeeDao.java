package com.cg.dao;

import com.cg.bean.Employee;

public interface EmployeeDao {

	void addEmployee(Employee employee);

	Employee searchEmployee(int emId);

	void beginTransaction();

	void commitTransaction();

	void removeEmployee(Employee employee);

	void updateEmployee(Employee employee3);

}
