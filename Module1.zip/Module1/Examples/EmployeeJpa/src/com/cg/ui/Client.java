package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int choice = 0;
		EmployeeService service=new EmployeeServiceImpl();
		do {
			System.out.println("Enter 1 to Add employee");
			System.out.println("Enter 2 to Remove employee");
			System.out.println("Enter 3 to search employee");
			System.out.println("Enter 4 to Update employee Details");
			System.out.println("Enter 5 to Exit");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				
				System.out.println("Enter the name of employee");
				String name=scanner.next();
				System.out.println("Enter the employee designation");
				String desig=scanner.next();
				System.out.println("Enter the salary of the employee");
				double salary=scanner.nextDouble();
				
				Employee employee=new Employee();
				employee.setEmpName(name);
				employee.setEmpDesignation(desig);
				employee.setEmpSalary(salary);
			
				if (service.validateEmployee(employee)) {
					service.addEmployee(employee);
				}else System.out.println("Could not add employee");
				break;
			case 2:
				System.out.println("Enter the id of employee to be removed");
				int empId=scanner.nextInt();
				if(service.removeEmployee(empId)) {
					System.out.println("Employee removed");
				}else System.out.println("Cannot remove");

				break;
			case 3:
				System.out.println("Enter the id of employee to be displayed ");
				int emId=scanner.nextInt();
				Employee employee2=service.searchEmployee(emId);
				if (employee2!=null) {
					System.out.println(employee2);	
				}else System.out.println("Employee doesnot exist");
				
				break;
				
			case 4:
				System.out.println("Enter the id of employee to be updated");
				int employeeId=scanner.nextInt();
				System.out.println("Enter the name of employee");
				String empName=scanner.next();
				System.out.println("Enter the employee designation");
				String empDesig=scanner.next();
				System.out.println("Enter the salary of the employee");
				double empSalary=scanner.nextDouble();
				
				Employee employee3=new Employee();
				employee3.setEmpId(employeeId);
				employee3.setEmpName(empName);
				employee3.setEmpDesignation(empDesig);
				employee3.setEmpSalary(empSalary);
				
				service.updateEmployee(employee3);
				break;

			default:
				System.out.println("Wrong choice");
				break;
			}
		} while (choice != 5);
		scanner.close();
	}

}
