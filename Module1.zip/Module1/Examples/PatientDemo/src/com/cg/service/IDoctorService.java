package com.cg.service;

import com.cg.dto.PatientDto;

public interface IDoctorService {

	public Integer addAppointmentDetails(PatientDto patientdto);

	public PatientDto viewAppointmentStatus(int pId);
}
