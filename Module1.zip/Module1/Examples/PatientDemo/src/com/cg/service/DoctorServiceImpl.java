package com.cg.service;

import com.cg.dao.DoctorDaoImpl;
import com.cg.dao.IDoctorDao;
import com.cg.dto.PatientDto;

public class DoctorServiceImpl implements IDoctorService {

	IDoctorDao dao = new DoctorDaoImpl();

	@Override
	public Integer addAppointmentDetails(PatientDto patientdto) {

		int generateId = (int) (Math.random() * 10000);
		String problemName = dao.showProblemName(patientdto.getProbName());
		if (null != problemName) {
			patientdto.setAppId(generateId);
			patientdto.setDocName(problemName);
			patientdto.setAppStatus("Approved");
			dao.addAppointmentDetails(patientdto);
		}
		return generateId;
	}

	@Override
	public PatientDto viewAppointmentStatus(int pId) {

		return dao.viewAppointmentStatus(pId);
	}

}
