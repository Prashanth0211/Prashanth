package com.cg.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.dto.PatientDto;
import com.cg.service.DoctorServiceImpl;
import com.cg.service.IDoctorService;

public class MyMain {
	public static void main(String[] args) {

		int choice = 0;
		IDoctorService service = new DoctorServiceImpl();
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Name");
				String name = scr.next();
				System.out.println("Enter PhoneNumber");
				long num = scr.nextLong();
				System.out.println("Enter email");
				String mail = scr.next();
				System.out.println("Enter Age");
				int age = scr.nextInt();
				System.out.println("Enter Gender");
				String gen = scr.next();
				System.out.println("Enter Problem Name");
				String pname = scr.next();
				System.out.println("Enter the Doj in dd-MMM-yyyy");
				String date = scr.next();
				DateTimeFormatter formate = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
				LocalDate myDate = LocalDate.parse(date, formate);
				PatientDto dto = new PatientDto();
				dto.setPatName(name);
				dto.setPhNum(num);
				dto.setEmail(mail);
				dto.setAge(age);
				dto.setGender(gen);
				dto.setProbName(pname);
				dto.setAppDate(myDate);
				service.addAppointmentDetails(dto);
				System.out.println("Appoinment Id is: " + dto.getAppId());
				break;
			case 2:
				System.out.println("Enter Id to view");
				int aid = scr.nextInt();
				PatientDto dt = service.viewAppointmentStatus(aid);
				if (dt != null) {
					System.out.println("Patient Name: " + dt.getPatName());
					System.out.println("Status: " + dt.getAppStatus());
					System.out.println("Patient Doctor: " + dt.getDocName());
				} else {
					System.out.println("Patient Not Found");
				}
				break;
			default:
				System.exit(0);
				break;
			}
		} while (choice != 5);
	}

	private static void printDetails() {
		System.out.println("MENU");
		System.out.println("1.Add Appointment Details");
		System.out.println("2.View Appointment Status");
		System.out.println("3.Exit");

	}
}
