package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.dto.PatientDto;

public class DoctorDaoImpl implements IDoctorDao {

	private static Map<String, String> doctorDetails = null;
	private static Map<Integer, PatientDto> patientDetails = null;

	static {
		doctorDetails = new HashMap<>();
		patientDetails = new HashMap<>();
		doctorDetails.put("Heart", "DOC-O");
		doctorDetails.put("Gynecology", "DOC-T");
		doctorDetails.put("Diabets", "DOC-TH");
		doctorDetails.put("ENT", "DOC-THU");
		doctorDetails.put("Bone", "DOC-F");
		doctorDetails.put("Dermatology", "DOC-S");
	}

	@Override
	public String showProblemName(String problem) {
		// TODO Auto-generated method stub
		return doctorDetails.get(problem);
	}

	@Override
	public void addAppointmentDetails(PatientDto dto) {
		patientDetails.put(dto.getAppId(), dto);

	}

	@Override
	public PatientDto viewAppointmentStatus(int pId) {

		return patientDetails.get(pId);
	}

}
