package com.cg.dao;

import com.cg.dto.PatientDto;

public interface IDoctorDao {

	public String showProblemName(String problem);

	public void addAppointmentDetails(PatientDto dto);

	public PatientDto viewAppointmentStatus(int pId);
}
