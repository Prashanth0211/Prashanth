package com.cg;

@FunctionalInterface
public interface IFactorial {
	int factorial(int n);
}
