package com.cg.demotwo.ui;

public class Employee {
	int empId;    //instance variables
	String empName;
	double empSal;
	boolean empScore;
	float data;
	public Employee() {
	
	System.out.println("In Constructor ");
	}
	public Employee(int empId,String empName,double empSal) {
	this.empId=empId;
	this.empName=empName;
	this.empSal=empSal;
	}
	public void printAllDetails() {
		System.out.println(empId+" "+empName+" "+empSal+" "+empScore+" "+data);
}
}
