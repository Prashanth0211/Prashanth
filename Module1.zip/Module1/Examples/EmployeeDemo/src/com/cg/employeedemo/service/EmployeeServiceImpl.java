package com.cg.employeedemo.service;

import java.util.ArrayList;

import com.cg.employeedemo.dao.EmployeeDaoImpl;
import com.cg.employeedemo.dao.IEmployeeDao;
import com.cg.employeedemo.dto.EmployeeDto;
import com.cg.employeedemo.staticdb.EmployeeDataBase;

public class EmployeeServiceImpl implements IEmployeeService {
 
	IEmployeeDao dao=new EmployeeDaoImpl();
	@Override
	public ArrayList<EmployeeDto> getAllEmployeeDetails() {
		
		return dao.getAllEmployeeDetails();
	}

	@Override
	public EmployeeDto getUniqueDetails(int eid) {
		
		
		return dao.getUniqueDetails(eid);
		
	}

	@Override
	public void addEmployeeDetails(EmployeeDto dto) {
		// TODO Auto-generated method stub
		dao.addEmployeeDetails(dto);
		
	}

	@Override
	public void modifySalary(int empid, double sal) {
		// TODO Auto-generated method stub
		
	}

	
	

}
