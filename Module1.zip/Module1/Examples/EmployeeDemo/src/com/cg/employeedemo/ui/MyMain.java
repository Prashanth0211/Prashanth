package com.cg.employeedemo.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.employeedemo.dto.EmployeeDto;
import com.cg.employeedemo.service.EmployeeServiceImpl;
import com.cg.employeedemo.service.IEmployeeService;
import com.cg.employeedemo.staticdb.EmployeeDataBase;

public class MyMain {

	public static void main(String[] args) {

		IEmployeeService service = new EmployeeServiceImpl();

		int choice = 0;
		do {
			printDetails();
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter choice");
			choice = scanner.nextInt();
			switch (choice) {

			case 1:
				ArrayList<EmployeeDto> list = new ArrayList<EmployeeDto>();
				list = service.getAllEmployeeDetails();
				for (EmployeeDto emp : list) {
					System.out.println("Employee Id:" + emp.getEmpId());
					System.out.println("Employee Name:" + emp.getEmpName());
					System.out.println("Employee Salary:" + emp.getEmpSalary());
					System.out.println("Employee Designation" + emp.getEmpDesignation());
				}
				break;
			case 2:
				System.out.println("Enter Id");
				int id = scanner.nextInt();
				EmployeeDto e = service.getUniqueDetails(id);
				System.out.println("Employee Id:" + e.getEmpId());
				System.out.println("Employee Name:" + e.getEmpName());
				System.out.println("Employee Salary:" + e.getEmpSalary());
				System.out.println("Employee Designation" + e.getEmpDesignation());
				break;

			case 3:
				System.out.println("Enter details of employee");
				System.out.println("Enter id");
				int eid = scanner.nextInt();
				System.out.println("Enter Name");
				String ename = scanner.next();
				System.out.println("Enter Salary");
				Double esal = scanner.nextDouble();
				System.out.println("Enter Designation");
				String edes = scanner.next();

				EmployeeDto dto = new EmployeeDto();
				dto.setEmpId(eid);
				dto.setEmpName(ename);
				dto.setEmpSalary(esal);
				dto.setEmpDesignation(edes);
				service.addEmployeeDetails(dto);
                break;
				
			case 4:
				System.out.println("Enter id");
				int empid = scanner.nextInt();
				System.out.println("Enter new Salary");
				double emsal = scanner.nextDouble();
				service.modifySalary(empid, emsal);
                break;
                
			case 5:
				System.exit(0);
				break;
			}
		} while (choice != 5);
	}

	public static void printDetails() {
		System.out.println("1.All Employee Details");
		System.out.println("2.One Employee Deatils");
		System.out.println("3.Add one more Employee");
		System.out.println("4.Modify Salary");
		System.out.println("5.Exit");

	}
}
