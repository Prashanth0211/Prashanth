package com.cg.demofour.ui;

import static java.lang.Math.*;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee emp=new Employee();
emp.empId=1001;
emp.empName="ABCD";
Employee empOne=new Employee();
empOne.empId=1002;
empOne.empName="BCD";
Employee empTwo=new Employee();
empTwo.empId=1003;
empTwo.empName="BCDE";

emp=empOne;
empOne=null;
empTwo=emp;

System.out.println("First Object ");
}
}
