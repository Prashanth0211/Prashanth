package com.cg.demofour.ui;

public class Employee {

	public int empId;
	public String empName;

}
