package com.cg.librarymanagement.exception;

public class LibraryManagementException extends Exception{

	public LibraryManagementException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LibraryManagementException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}


}
