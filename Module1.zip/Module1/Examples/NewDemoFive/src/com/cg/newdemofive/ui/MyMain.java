package com.cg.newdemofive.ui;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int number[]= {10,20,30,40};
		int mun[][]=new int[1][];
		int num[]=new int[4];
		
		num[0]=10;
		num[1]=20;
		num[2]=30;
		num[3]=40;
		
		//for(int i=0;i<num.length;i++) {
			//System.out.println(num[i]);
		//}
		
		for(int i:num) {
			System.out.println(i);
		}
	}

}
