package com.cg.demoseven.ui;

public class Person {

}
