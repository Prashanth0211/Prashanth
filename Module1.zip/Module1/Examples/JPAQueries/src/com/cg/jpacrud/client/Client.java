package com.cg.jpacrud.client;

import java.util.Scanner;

import com.cg.jpacrud.entities.Book;
import com.cg.jpacrud.service.BookService;
import com.cg.jpacrud.service.BookServiceImpl;

public class Client {

	public static void main(String[] args) {

		BookService service = new BookServiceImpl();
		int choice = 0;
		do {
			printDetails();
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("************Listing total number of books*************");
				System.out.println("Total books:" + service.getBookCount());
				break;
			case 2:
				System.out.println("************Listing book with id 105*************");
				System.out.println("Boo with ID 106:" + service.getBookById(106));
				break;
			case 3:
				System.out.println("************Listing All books*************");
				for (Book book : service.getAllBooks()) {
					System.out.println(book);
				}
				break;
			case 4:
				System.out.println("************Listing book written by Danny Coward*************");
				for (Book book : service.getAuthorBooks("Danny Coward")) {
					System.out.println(book);
				}
				break;
			case 5:
				System.out.println("************Listing book on Android*************");
				for (Book book : service.getBookByTitle("Android")) {
					System.out.println(book);
				}
				break;
			case 6:
				System.out.println("************Listing All books between 500 and 600*************");
				for (Book book : service.getBooksInPriceRange(500, 600)) {
					System.out.println(book);
				}
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Enter valid choice");
				break;
			}
		} while (choice != 7);

	}

	private static void printDetails() {

		System.out.println("1.BookCount");
		System.out.println("2.BookById");
		System.out.println("3.AllBooks");
		System.out.println("4.AuthorBooks");
		System.out.println("5.BookByTitle");
		System.out.println("6.BooksInPriceRange");
		System.out.println("7.Exit");
	}
}
