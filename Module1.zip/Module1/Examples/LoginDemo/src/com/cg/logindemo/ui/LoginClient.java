package com.cg.logindemo.ui;

import java.util.Scanner;

import com.cg.logindemo.dto.UserBean;
import com.cg.logindemo.exception.MyLoginException;
import com.cg.logindemo.service.ILoginService;
import com.cg.logindemo.service.LoginServiceImpl;

public class LoginClient {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter UserName");
		String username = scanner.next();
		System.out.println("Enter Password");
		String password = scanner.next();
		ILoginService service = new LoginServiceImpl();
		UserBean userBean = new UserBean();
		userBean.setUserName(username);
		userBean.setPassword(password);
		boolean result = service.validateLogin(userBean);
		if (result) {
           boolean output=false;
           try {
           output=service.verifyLogin(userBean);
		       } catch(MyLoginException e) {
        	   System.out.println(e.getMessage());
           }
           if (output) {
			System.out.println("Welcome"+username);
		} else {
             System.out.println("Invalid Login.Try Again");
		}
		} else {
			  System.out.println("Invalid Login.Try Again");
		}

	}

}
