package com.cg.logindemo.staticdb;

import java.util.HashMap;

public class LoginDataBase {

	private static HashMap<String, String> hashMap = null;
	static {
		hashMap = new HashMap<>();
	}

	public static HashMap<String, String> getLoginDetails() {

		hashMap.put("Prashanth", "Prashanth");
		hashMap.put("Admin", "Admin");
		hashMap.put("admin", "32145");

		return hashMap;
	}
}
