package com.cg.logindemo.dao;

import com.cg.logindemo.dto.UserBean;
import com.cg.logindemo.exception.MyLoginException;

public interface ILoginDao {
	public String getLoginPassword(UserBean userbean) throws MyLoginException;
}
