package com.cg.logindemo.exception;

public interface MyLoginExceptionMessages {

	String ERROR1 = "Internal Error Try Again";

}
