package com.cg.logindemo.exception;

public class MyLoginException extends Exception {

	public MyLoginException() {
		
	}

	public MyLoginException(String Message) {
		super(Message);
	}

}
