package com.cg.logindemo.service;

import com.cg.logindemo.dao.ILoginDao;
import com.cg.logindemo.dao.LoginDaoImpl;
import com.cg.logindemo.dto.UserBean;
import com.cg.logindemo.exception.MyLoginException;

public class LoginServiceImpl implements ILoginService {
	private ILoginDao dao;

	public LoginServiceImpl() {
		dao = new LoginDaoImpl();
	}

	@Override
	public boolean validateLogin(UserBean userBean) {
		boolean result = false;
		if (userBean.getUserName().trim().length() > 4 && userBean.getPassword().trim().length() > 4) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean verifyLogin(UserBean userbean) throws MyLoginException {
		boolean output=false;
		String dbPassword=dao.getLoginPassword(userbean);
		if (userbean.getPassword().equals(dbPassword)) {
			output=true;
		}
		return output;
	}

}
