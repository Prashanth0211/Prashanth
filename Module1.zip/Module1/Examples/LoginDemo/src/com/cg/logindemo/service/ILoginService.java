package com.cg.logindemo.service;

import com.cg.logindemo.dto.UserBean;
import com.cg.logindemo.exception.MyLoginException;

public interface ILoginService {
public boolean validateLogin(UserBean userBean);
public boolean verifyLogin(UserBean userbean) throws MyLoginException; 
}
