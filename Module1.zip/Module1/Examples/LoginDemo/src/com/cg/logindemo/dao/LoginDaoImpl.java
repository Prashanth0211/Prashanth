package com.cg.logindemo.dao;

import java.util.HashMap;

import com.cg.logindemo.dto.UserBean;
import com.cg.logindemo.exception.MyLoginException;
import com.cg.logindemo.exception.MyLoginExceptionMessages;
import com.cg.logindemo.staticdb.LoginDataBase;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public String getLoginPassword(UserBean userbean) throws MyLoginException {
		String dbPassword="-1";
		try {
		HashMap<String, String> db=LoginDataBase.getLoginDetails();
		dbPassword=db.get(userbean.getUserName());
		System.out.println(dbPassword);
		}catch (Exception exception) {
			throw new MyLoginException(MyLoginExceptionMessages.ERROR1);
		}
		return dbPassword;
	}

}
