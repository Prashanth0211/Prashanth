package com.cg.mra.exception;

public interface AccountExceptionMessgae {

	String ERROR = "Given Account Id Does Not Exists";
}
