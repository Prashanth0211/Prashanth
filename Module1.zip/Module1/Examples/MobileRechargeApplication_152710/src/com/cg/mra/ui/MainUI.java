package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.bean.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws AccountException {

		int choice = 0;
		AccountService service = new AccountServiceImpl();
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Mobile Number: ");
				String num = scr.next();
				Account dto = new Account();
				boolean error = false;
				try {
					error = service.validateNumber(num);
				} catch (AccountException e) {
					System.out.println(e.getMessage());
				}
				if (error) {
					Account account = service.getAccountDetails(num);
					if (account != null) {
						System.out.println("Your Current Balance is Rs." + account.getAccountBalance());
					} else {
						System.out.println("Given Acccount Id Does Not Exists");
					}
				}
				break;
			case 2:
				System.out.println("Enter MobileNo: ");
				String mnum = scr.next();
				System.out.println("Enter Recharge Amount");
				double amount = scr.nextDouble();
				boolean output = false;
				try {
					output = service.validateNumber(mnum);
				} catch (AccountException e) {
					System.out.println(e.getMessage());
				}

				if (output) {
					service.rechargeAccount(mnum, amount);
					Account acc = service.getAccountDetails(mnum);
					if (acc != null) {
						System.out.println("Your Account Recharged Successfully");
						System.out.println("Hello Prashanth,Available Balance is " + acc.getAccountBalance());
					} else {
						System.out.println("Cannot Recharge Account as Given Mobile No Does Not Exists");
					}
				}
				break;
			default:
				System.exit(0);
				break;
			}
		} while (choice != 4);

	}

	private static void printDetails() {
		// TODO Auto-generated method stub

		System.out.println("---------MENU--------");
		System.out.println("1.Account Balance Enquiry");
		System.out.println("2.Recharge Account");
		System.out.println("3.Exit");
	}
}
