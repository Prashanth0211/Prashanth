package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.bean.Account;

public interface AccountDao {

	Account getAccountDetails(String mobileNo);

	boolean rechargeAccount(String mobileno, double rechargeAmount);

	public HashMap<String, Account> viewDetails(String id);
}
