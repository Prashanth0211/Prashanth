package com.cg.mra.service;

import java.util.HashMap;

import com.cg.mra.bean.Account;
import com.cg.mra.exception.AccountException;

public interface AccountService {

	Account getAccountDetails(String mobileNo);

	boolean rechargeAccount(String mobileno, double rechargeAmount);

	public boolean validateNumber(String num) throws AccountException;

	public HashMap<String, Account> viewDetails(String id);

}
