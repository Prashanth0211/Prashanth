package com.cg.hashdemo.dao;

public interface IStudentDao {

}
