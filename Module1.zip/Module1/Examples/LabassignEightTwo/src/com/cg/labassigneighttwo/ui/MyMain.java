package com.cg.labassigneighttwo.ui;

import java.util.Date;

public class MyMain implements Runnable{

	public static void main(String[] args) {
		Thread thread=new Thread(new MyMain());
		thread.start();
		
	}

	@Override
	public void run() {
		
		while(true) {
			System.out.println(new Date());
			try {
				Thread.sleep(10000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
