import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DemoregEx {

	public static void main(String[] args) {
		
		
		String name=new Scanner(System.in).next().trim();
		//Pattern pattern=Pattern.compile("{^[a-zA-Z]{1, }$}" );
		//Matcher matcher=pattern.matcher(name);
		String pattern="[a-zA-Z]{1,}";
		if(name.matches(pattern)) {
			System.out.println("Success");
		}else {
			System.out.println("Fail");
		}

	}

}
