package com.cg.service;

import java.util.Set;

import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;

public interface EmployeeService {

	public void addEmployee(Employee emp) throws EmployeeException;

	public Employee getEmployeeDetails(int employeeId) throws EmployeeException;
}