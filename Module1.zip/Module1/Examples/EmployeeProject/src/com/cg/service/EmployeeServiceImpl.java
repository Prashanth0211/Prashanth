package com.cg.service;

import java.util.Set;

import com.cg.dao.EmployeeServiceDao;
import com.cg.dao.EmployeeServiceDaoImpl;
import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeServiceDao dao = new EmployeeServiceDaoImpl();

	@Override
	public void addEmployee(Employee emp) throws EmployeeException {

		dao.addEmployee(emp);
	}

	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeDetails(employeeId);
	}

	
}
