package com.cg.exception;

public class EmployeeException extends Exception {

	public EmployeeException() {
		// TODO Auto-generated constructor stub
	}

	public  EmployeeException(String msg) {
		System.out.println(msg);
	}

	
}
