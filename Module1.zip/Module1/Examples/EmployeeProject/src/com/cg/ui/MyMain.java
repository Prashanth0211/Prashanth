package com.cg.ui;

import java.util.Scanner;
import java.util.Set;

import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

public class MyMain {

	public static void main(String[] args) {

		int choice = 0;
		EmployeeService service = new EmployeeServiceImpl();
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Id:");
				int eid = scr.nextInt();
				System.out.println("Enter Name:");
				String ename = scr.next();
				System.out.println("Enter salary:");
				double esal = scr.nextDouble();

				Employee emp = new Employee();
				emp.setId(eid);
				emp.setName(ename);
				emp.setSalary(esal);

				if (esal > 5000 && esal < 20000) {
					emp.setDesignation("SystemAssociate");
					emp.setInsuranceScheme("SchemeC");
				} else if (esal >= 20000 && esal < 40000) {
					emp.setDesignation("Programmer");
					emp.setInsuranceScheme("SchemeB");
				} else if (esal >= 4000) {
					emp.setDesignation("Manager");
					emp.setInsuranceScheme("SchemeA");
				} else if (esal < 5000) {
					emp.setDesignation("Clerk");
					emp.setInsuranceScheme("NoScheme");
				}
				try {
					service.addEmployee(emp);
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 2:
				Employee employee = new Employee();
				System.out.print("\nEnter Employee Id : ");
				int employeeId = scr.nextInt();
				try {
					employee = service.getEmployeeDetails(employeeId);
					System.out.println("Employee Id: " + employee.getId());
					System.out.println("Employee Name: " + employee.getName());
					System.out.println("Employee Salary: " + employee.getSalary());
					System.out.println("Employee Designation: " + employee.getDesignation());
					System.out.println("Employee InsuranceScheme: " + employee.getInsuranceScheme());
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("Enter valid choice");
				break;
			}
		} while (choice != 5);

	}

	private static void printDetails() {
		System.out.println("1.Add Employee");
		System.out.println("2.Show Employee");
		System.out.println("3.Exit");

	}

}
