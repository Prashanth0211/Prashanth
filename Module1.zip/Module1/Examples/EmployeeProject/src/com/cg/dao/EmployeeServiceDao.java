package com.cg.dao;

import java.util.Set;

import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;

public interface EmployeeServiceDao {
	public void addEmployee(Employee emp) throws EmployeeException;

	public Employee getEmployeeDetails(int employeeId) throws EmployeeException;
	
}
