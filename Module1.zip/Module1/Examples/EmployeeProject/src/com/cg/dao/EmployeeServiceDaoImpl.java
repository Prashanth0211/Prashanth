package com.cg.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;
import com.cg.dto.Employee;
import com.cg.exception.EmployeeException;
import com.cg.util.DBUtil;

public class EmployeeServiceDaoImpl implements EmployeeServiceDao {

	Connection con = null;

	public EmployeeServiceDaoImpl() {// throws TakeCareClinicException {

		try {
			con = DBUtil.getConnect();
		} catch (EmployeeException e) {

			e.printStackTrace();
		} 
	}

	@Override
	public void addEmployee(Employee emp) throws EmployeeException {
		try {
			String sql = "INSERT INTO Employee VALUES(?, ?, ?, ?, ?)";

			PreparedStatement pstmt = con.prepareStatement(sql);
			System.out.println(emp);
			pstmt.setInt(1, emp.getId());
			pstmt.setString(2, emp.getName());
			pstmt.setDouble(3, emp.getSalary());
			pstmt.setString(4, emp.getDesignation());
			pstmt.setString(5, emp.getInsuranceScheme());
			int row = pstmt.executeUpdate();
			if (row > 0) {

			} else {

				throw new EmployeeException("System Error. Try Again Later.");

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeException {
		Employee employee=new Employee();
		try {
			String sql = "SELECT * FROM Employee WHERE ID= ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, employeeId);
			ResultSet res = pstmt.executeQuery();
			if(res.next()) {
				employee.setId(res.getInt(1));
				employee.setName(res.getString(2));
				employee.setSalary(res.getDouble(3));
				employee.setDesignation(res.getString(4));
				employee.setInsuranceScheme(res.getString(5));
				}
			else {
				throw new EmployeeException("Employee not found");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return employee;
	}

	
}
