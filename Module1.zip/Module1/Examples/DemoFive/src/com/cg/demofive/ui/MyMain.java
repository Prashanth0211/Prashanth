package com.cg.demofive.ui;

public class MyMain {
	static int data;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(data);

	getData();
	new MyMain();
	}
	public static void getData() {
		System.out.println("In static block....");
		
	}
	{
		System.out.println("Call after Static...");
	}
	static {
		System.out.println("execute first...");
	}
	public void showData() {
		System.out.println("In non-static...");
		getData();
	}

}
