package com.cg.labassignthreefour.ui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DateTimeFormatter formate=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the Date in dd/mm/yyyy");
		String date=scr.next();
		LocalDate myDate=LocalDate.parse(date,formate);
		Scanner scr1=new Scanner(System.in);
		System.out.println("Enter the Date in dd/mm/yyyy");
		String date1=scr1.next();
		LocalDate newDate=LocalDate.parse(date1,formate);
		Period diff=myDate.until(newDate);
		System.out.println("Days: "+diff.getDays());
		System.out.println("Months: "+diff.getMonths());
		System.out.println("Years: "+diff.getYears());
	}

}
