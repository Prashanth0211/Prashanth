package com.cg.demoone.ui;

public class Mymain {

	public static void main(String[] args) {
		int numberOne=Integer.parseInt(args[0]);
		int numberTwo=Integer.parseInt(args[1]);
		
		Calculator cal=new Calculator();
		int addResult=cal.addNumber(numberOne,numberTwo);
		int subResult=cal.subNumber(numberOne,numberTwo);
		int mulResult=cal.mulNumber(numberOne,numberTwo);
		int divResult=cal.divNumber(numberOne,numberTwo);
		
		System.out.println(" addition is " +addResult+" subtraction is "+subResult);
		System.out.println(" multiplication is " +mulResult+" division is "+divResult);	
	}

}
