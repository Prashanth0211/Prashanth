package com.cg.arraydemotwo.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class MyMain {

	public static void main(String[] args) {
		
	
		List<String> myList=new LinkedList<>();
		
		myList.add("A");
		myList.add("B");
		myList.add("C");
		myList.add("A");
	    
		
	
		System.out.println(myList);
		System.out.println(myList.get(2));
	
		System.out.println("-----Enhance for loop-----");
	    for(String str:myList) {
		System.out.println(str);
	    }
	
	    System.out.println("------Iterator-------");
	
	    Iterator it=myList.iterator();
	    while(it.hasNext()) {
		System.out.println(it.next());
		}
	
  }
}
