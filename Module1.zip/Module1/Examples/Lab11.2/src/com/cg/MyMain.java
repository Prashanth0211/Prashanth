package com.cg;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
IAddSpace space=(string)->{
	StringBuilder builder=new StringBuilder();
	for(int i=0;i<string.length();i++)
	{
		builder.append(string.charAt(i)+" ");
	}
	return builder.toString();
};
System.out.println(space.spaceAdd("CG"));
	}

}

