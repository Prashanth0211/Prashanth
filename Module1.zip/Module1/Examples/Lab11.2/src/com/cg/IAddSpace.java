package com.cg;

@FunctionalInterface
public interface IAddSpace {
String spaceAdd(String str );
}
