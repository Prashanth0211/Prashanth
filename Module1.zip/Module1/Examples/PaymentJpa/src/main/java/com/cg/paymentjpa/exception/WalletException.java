package com.cg.paymentjpa.exception;

public class WalletException extends Exception {

	public WalletException() {
		super();
	}

	public WalletException(String message) {
		System.out.println(message);
	}
}
