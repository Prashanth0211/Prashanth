package com.cg.labassignfourtwo.ui;

public class CurrentAccount extends Account {
	final double overDraft_limit=1000;
	
	
	public CurrentAccount() {
		
	}

	public CurrentAccount(String name, double bal, float age) {
		super();
		this.name = name;
		this.bal = bal;
		this.age = age;
	}

	public void withdraw(double d) {
		double b=bal;
		b-=d;
		if(b>=overDraft_limit) {
			System.out.println("You have reached your limit");
		}
		else
			bal=b;
	}

	@Override
	public String toString() {
		return "CurrentAccount [name=" + name + ", bal=" + bal + ", age=" + age + "]";
	}


	
}
