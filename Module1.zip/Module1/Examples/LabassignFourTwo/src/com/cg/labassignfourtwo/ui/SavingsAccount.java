package com.cg.labassignfourtwo.ui;

public class SavingsAccount extends Account {
final double minBal=1000;

public SavingsAccount() {
	
}

public SavingsAccount(String name, double bal, float age) {
	super();
	this.name = name;
	this.bal = bal;
	this.age = age;
}

public void withdraw(double d) {
	double b=bal;
	b-=d;
	if(b<=minBal) {
		System.out.println("No sufficient amount to withdraw");
	}
	else
		bal=b;
}

@Override
public String toString() {
	return "SavingsAccount [name=" + name + ", bal=" + bal + ", age=" + age + "]";
}


  

}
