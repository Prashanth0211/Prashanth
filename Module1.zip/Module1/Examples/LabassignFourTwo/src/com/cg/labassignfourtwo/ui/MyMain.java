package com.cg.labassignfourtwo.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		SavingsAccount sa=new SavingsAccount("Prashanth",2000.00,25);
		CurrentAccount ca=new CurrentAccount("Shivaram",500.00,47);
		
		System.out.println("SavingsAccount: ");
		System.out.println(sa);
		System.out.println("CurrentAccount: ");
		System.out.println(ca);
		
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter amount to withdraw from SavingsAccount");
		double withdraw=scr.nextDouble();
		sa.withdraw(withdraw);
		System.out.println("Enter amount to withdraw from CurrentAccount");
		double withdraw1=scr.nextDouble();
		ca.withdraw(withdraw1);
		
		System.out.println("After withdraw account balances are:");
		System.out.println(sa);
		System.out.println(ca);
	}

	
}

