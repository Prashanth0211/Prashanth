package com.cg.librarydemo.service;

import com.cg.librarydemo.dto.LibraryDto;

public interface ILibraryService {

	public LibraryDto viewMemberDetails(String memid);

	public boolean payAmount(String memid, double amount);
}
