package com.cg.librarydemo.service;

import com.cg.librarydemo.dao.ILibraryDao;
import com.cg.librarydemo.dao.LibraryDaoImpl;
import com.cg.librarydemo.dto.LibraryDto;

public class LibraryServiceImpl implements ILibraryService {

	ILibraryDao dao = new LibraryDaoImpl();

	@Override
	public LibraryDto viewMemberDetails(String memid) {

		return dao.viewMemberDetails(memid);
	}

	@Override
	public boolean payAmount(String memid, double amount) {
		
		return dao.payAmount(memid, amount);
	}

}
