package com.cg.librarydemo.dto;

public class LibraryDto {

	private String memId;
	private String memName;
	private double amount;

	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public String getMemName() {
		return memName;
	}

	public void setMemName(String memName) {
		this.memName = memName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "LibraryDto [memId=" + memId + ", memName=" + memName + ", amount=" + amount + "]";
	}

}
