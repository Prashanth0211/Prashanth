package com.cg.librarydemo.dao;

import com.cg.librarydemo.dto.LibraryDto;

public interface ILibraryDao {

	public LibraryDto viewMemberDetails(String memid);

	public boolean payAmount(String memid, double amount);

}
