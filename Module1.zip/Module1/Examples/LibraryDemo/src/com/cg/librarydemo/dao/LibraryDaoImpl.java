package com.cg.librarydemo.dao;

import java.util.HashMap;

import com.cg.librarydemo.dto.LibraryDto;

public class LibraryDaoImpl implements ILibraryDao {

	private static HashMap<String, LibraryDto> hashmap = null;
	static {
		hashmap = new HashMap<>();

		LibraryDto cus1 = new LibraryDto();
		cus1.setMemId("ABC4");
		cus1.setMemName("Prashanth");
		cus1.setAmount(-100.00);

		LibraryDto cus2 = new LibraryDto();
		cus2.setMemId("BCD4");
		cus2.setMemName("Roshini");
		cus2.setAmount(-100.00);

		LibraryDto cus3 = new LibraryDto();
		cus3.setMemId("CDE4");
		cus3.setMemName("Lokesh");
		cus3.setAmount(-100.00);

		hashmap.put("ABC4", cus1);
		hashmap.put("BCD4", cus2);
		hashmap.put("CDE4", cus3);

	}

	@Override
	public LibraryDto viewMemberDetails(String memid) {

		return hashmap.get(memid);
	}

	@Override
	public boolean payAmount(String memid, double amount) {
		boolean result = false;
		if (hashmap.containsKey(memid)) {
			LibraryDto dto = new LibraryDto();
			String memName = hashmap.get(memid).getMemName();
			double balance = hashmap.get(memid).getAmount();
			dto.setMemId(memid);
			dto.setMemName(memName);
			dto.setAmount(balance + amount);

			hashmap.remove(memid);
			hashmap.put(memid, dto);

			result = true;
		}
		return result;
	}

}
