package com.cg.librarydemo.ui;

import java.util.Scanner;

import com.cg.librarydemo.dto.LibraryDto;
import com.cg.librarydemo.service.ILibraryService;
import com.cg.librarydemo.service.LibraryServiceImpl;

public class MyMain {

	public static void main(String[] args) {
		int choice = 0;
		ILibraryService service = new LibraryServiceImpl();
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter member ID: ");
				String id = scr.next();
				System.out.println(service.viewMemberDetails(id));
				
				break;
			case 2:
				System.out.println("Enter Id: ");
				String mid=scr.next();
				System.out.println("Enter Amount: ");
				double amount=scr.nextDouble();
				service.payAmount(mid, amount);
				break;
			default:
				System.exit(0);
				break;
			}
		} while (choice != 4);

	}

	public static void printDetails() {
		System.out.println("MENU");
		System.out.println("1.View Member Details");
		System.out.println("2.Pay Amount");
		System.out.println("3.Exit");
	}
}
