package com.cg.newdemotwo.service;

public interface IEmployeeServices {
     
	public void getData();//public abstract
	public double showData();//public abstract
	
	int a=10;//static final
	
	
	
}
