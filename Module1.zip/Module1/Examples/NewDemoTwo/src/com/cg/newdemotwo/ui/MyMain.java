package com.cg.newdemotwo.ui;

import com.cg.newdemotwo.service.EmployeeService;
import com.cg.newdemotwo.service.IEmployeeServices;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IEmployeeServices emp=new EmployeeService();
		System.out.println(emp.a);
		emp.getData();
		
		double data=emp.showData();
		System.out.println(data);
		
	}

}
