package com.cg.newdemotwo.service;

public class EmployeeService implements IEmployeeServices,A {

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		System.out.println("In getData....");
	}

	@Override
	public double showData() {
		// TODO Auto-generated method stub
		return 2.0;
	}

}
