package com.cg.newdemotwo.service;

public interface A extends IEmployeeServices {

}
