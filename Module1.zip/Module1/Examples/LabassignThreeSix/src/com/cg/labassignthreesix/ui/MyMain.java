package com.cg.labassignthreesix.ui;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDateTime today=LocalDateTime.now();
	      
	       System.out.println(today);
	       
	     ZonedDateTime zoneIndia=ZonedDateTime.now();
			System.out.println(zoneIndia);
			
			ZonedDateTime zoneFrance=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
			System.out.println(zoneFrance);
			
			ZonedDateTime zoneSydney=ZonedDateTime.now(ZoneId.of("Australia/Sydney"));
			System.out.println(zoneSydney);
			
			ZonedDateTime zoneTokyo=ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
			System.out.println(zoneTokyo);
			
			ZonedDateTime zoneNewYork=ZonedDateTime.now(ZoneId.of("America/New_York"));
			System.out.println(zoneNewYork);
			
			
	}

}
