public class Demo1{
public static void main(String args[]){
Calculator cal=new Calculator();
int i=Integer.parseInt(args[0]);
int j=Integer.parseInt(args[1]);
System.out.println("sum is "+cal.add(i,j));
System.out.println("sub is "+cal.sub(i,j));
System.out.println("mul is "+cal.mul(i,j));
System.out.println("div is "+cal.div(i,j));
}
}