package com.cg;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class MyMain {

	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(new File("numbers.txt")));
		String nums;

		while ((nums = br.readLine()) != null) {
			String[] numArray = nums.split(",");
			for (String string2 : numArray) {
				if (Integer.parseInt(string2) % 2 == 0) {
					System.out.println(string2);
				}
			}
		}
	}

}
