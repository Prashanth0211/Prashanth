class Calculator{

public add(int a,int b){
return(a+b);
}
public sub(int a,int b){
return(a-b);
}
public mul(int a,int b){
return(a*b);
}
public div(int a,int b){
return(a/b);
}
}