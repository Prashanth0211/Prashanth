package com.cg.labassignsixtwo.exception;

public class AccountException extends Exception {

	public AccountException() {
		super();
	}
	public AccountException(String msg) {
		super(msg);
	}
}
