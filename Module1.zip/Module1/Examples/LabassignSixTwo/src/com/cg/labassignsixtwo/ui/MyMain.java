package com.cg.labassignsixtwo.ui;

import java.util.Scanner;

import com.cg.labassignsixtwo.exception.AccountException;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr=new Scanner(System.in);
		System.out.println("Enter age");
		int page=scr.nextInt();
		Account acc=new Account();
		try {
			acc.setAge(page);
		} catch (AccountException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
	}

}
