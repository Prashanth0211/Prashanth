package com.cg.labassigntwoone.ui;

public class MyMain {
	
	public static void main(String[] args) {

	System.out.println("Personal Details:");
	System.out.println("_________________");
	System.out.println("FirstName: Divya");
	System.out.println("Last Name: Bharathi");
	System.out.println("Gender: F");
	System.out.println("Age: 20");
	System.out.println("Weight: 85.55");
	}
	
	}
