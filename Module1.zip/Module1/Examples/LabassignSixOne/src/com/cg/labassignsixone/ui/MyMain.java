package com.cg.labassignsixone.ui;

import java.util.Scanner;

import com.cg.labassignsixone.exception.EmployeeException;



public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr=new Scanner(System.in);
		System.out.println("Enter first name");
		String fname=scr.nextLine();
		System.out.println("Enter last name");
		String lname=scr.nextLine();
		Employee emp=new Employee();
		
		try {
			emp.setFirstName(fname);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
             System.out.println(e.getMessage());
		}
		
		try {
			emp.setLastName(lname);
		} catch (EmployeeException e1) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
             System.out.println(e1.getMessage());
		}
		
	}

}
