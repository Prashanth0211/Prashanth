package com.cg.labassignsixone.ui;

import com.cg.labassignsixone.exception.EmployeeException;

public class Employee {

	private String firstName;
	private String lastName;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) throws EmployeeException{
		if(firstName.isEmpty()) {
			throw new EmployeeException("First name is blank");
		}
		else {
			this.firstName = firstName;	
		}
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) throws EmployeeException {
		if(lastName.isEmpty()) {
			throw new EmployeeException("Second name is blank");
		}
		else {
			this.lastName = lastName;		
	}
		
	}
	

}
