package com.cg.eis.service;

import java.util.Set;

import com.cg.eis.bean.Employee;

public interface IEmployeeService {

	public void addEmployee(Employee emp);

	public Set<Employee> showSortedEmployee();

	public void deleteEmployee(int eid);

	public Employee searchEmployee(String scheme);
}
