package com.cg.eis.ui;

import java.util.Scanner;
import java.util.Set;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;

public class MyMain {

	public static void main(String[] args) {

		int choice = 0;
		IEmployeeService service = new EmployeeServiceImpl();
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Id:");
				int eid = scr.nextInt();
				System.out.println("Enter Name:");
				String ename = scr.next();
				System.out.println("Enter salary:");
				double esal = scr.nextDouble();

				Employee emp = new Employee();
				emp.setId(eid);
				emp.setName(ename);
				emp.setSalary(esal);

				if (esal > 5000 && esal < 20000) {
					emp.setDesignation("System Associate");
					emp.setInsuranceScheme("Scheme C");
				} else if (esal >= 20000 && esal < 40000) {
					emp.setDesignation("Programmer");
					emp.setInsuranceScheme("Scheme B");
				} else if (esal >= 4000) {
					emp.setDesignation("Manager");
					emp.setInsuranceScheme("Scheme A");
				} else if (esal < 5000) {
					emp.setDesignation("Clerk");
					emp.setInsuranceScheme("No Scheme");
				}
				service.addEmployee(emp);
				break;

			case 2:
				Set<Employee> allData = service.showSortedEmployee();
				for (Employee employee : allData) {
					System.out.println("Id: " + employee.getId());
					System.out.println("Name: " + employee.getName());
					System.out.println("Salary: " + employee.getSalary());
					System.out.println("Designation: " + employee.getDesignation());
					System.out.println("InsuranceScheme: " + employee.getInsuranceScheme());
				}
				break;
			case 3:
				System.out.println("Enter Employee InsuranceScheme");
				String scheme = scr.next();
				Employee empsearch = service.searchEmployee(scheme);
				if (empsearch == null) {
					System.out.println("Employee Not Found");
				} else {
					System.out.println("Id: " + empsearch.getId());
					System.out.println("Name: " + empsearch.getName());
					System.out.println("Salary: " + empsearch.getSalary());
					System.out.println("Designation: " + empsearch.getDesignation());
					System.out.println("InsuranceScheme: " + empsearch.getInsuranceScheme());
				}
				break;
			case 4:
				System.out.println("Enter Id to delete");
				int id = scr.nextInt();
				service.deleteEmployee(id);
				break;
			default:
				System.exit(0);
				break;
			}
		} while (choice != 5);

	}

	private static void printDetails() {
		System.out.println("1.Add Employee");
		System.out.println("2.Sort Employee");
		System.out.println("3.Search Employee");
		System.out.println("4.Delete Employee");
		System.out.println("5.Exit");
	}
}
