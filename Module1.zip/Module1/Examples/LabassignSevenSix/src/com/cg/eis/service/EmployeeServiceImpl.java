package com.cg.eis.service;

import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements IEmployeeService {

	HashMap<Integer, Employee> myMap = new HashMap<Integer, Employee>();
	Set<Employee> mySet = new TreeSet<>();
	int key = 1;

	@Override
	public void addEmployee(Employee emp) {
		System.out.println("Employee added Successfully");
		mySet.add(emp);
		myMap.put(key++, emp);
	}

	@Override
	public Set<Employee> showSortedEmployee() {
		// TODO Auto-generated method stub
		return mySet;
	}

	@Override
	public void deleteEmployee(int eid) {
		Set<Integer> keys = myMap.keySet();
		for (Integer integer : keys) {
			if (eid == integer) {
				myMap.remove(eid);
			}
		}
		int found = 0;
		for (Employee emp : mySet) {
			if (emp.getId() == eid) {
				mySet.remove(emp);
				found = 1;
				break;
			}
		}
		if (found == 1) {
			System.out.println("Employee id with " + eid + "is deleted");
		} else
			System.out.println("Employee Not Found");

	}

	@Override
	public Employee searchEmployee(String scheme) {
		Employee psearch = null;
		for (Employee emp : mySet) {
			if (emp.getInsuranceScheme().trim() == scheme.trim()) {
				psearch = emp;
				break;
			}
		}
		return psearch;
	}

}
