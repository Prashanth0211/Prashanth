package com.cg.PaymentWalletJpa.dao;

import java.util.List;
import javax.persistence.EntityManager;
import com.cg.PaymentWalletJpa.dto.Customer;
import com.cg.PaymentWalletJpa.dto.Wallet;

public class WalletApplicationDAOImpl implements IWalletApplicationDAO {

	private EntityManager manager;

	public WalletApplicationDAOImpl() {
		manager = JPAUtil.getEntityManager();
	}

	

	public int createAccount(Customer details) {
		manager.persist(details);
		return 1;
	}

	public Customer login(String username, String password) {

		String password1 = null;
		Customer customer = manager.find(Customer.class, username);
		password1 = customer.getPassword();
		if (password1.equals(password)) {
			return customer;
		} else
			return null;
	}

	public double showBalance(String phoneNo) {
		double balance = manager.find(Customer.class, phoneNo).getWallet().getAmount();
		return balance;
	}

	public int deposit(String phoneNo, double amount) {
		Customer wallet = manager.find(Customer.class, phoneNo);
		wallet.getWallet().setAmount(wallet.getWallet().getAmount() + amount);
		manager.merge(wallet);
		return 1;
	}

	public int withdraw(String phoneNo, double amount) {
		Customer wallet = manager.find(Customer.class, phoneNo);
		wallet.getWallet().setAmount(wallet.getWallet().getAmount() - amount);
		manager.merge(wallet);
		return 1;
	}

	public int fundTransfer(String senderphoneNo, String recieverphoneNo, double amount) {
		Customer wallet = manager.find(Customer.class, senderphoneNo);
		wallet.getWallet().setAmount(wallet.getWallet().getAmount() - amount);
		manager.merge(wallet);

		Customer wallet1 = manager.find(Customer.class, recieverphoneNo);
		wallet1.getWallet().setAmount(wallet1.getWallet().getAmount() + amount);
		manager.merge(wallet1);
		return 1;
	}

	public List printTrans() {
		
		return null;
	}



	public void beginTransaction() {
		
		manager.getTransaction().begin();
	}



	public void commitTransaction() {
	
		manager.getTransaction().commit();
	}

}
