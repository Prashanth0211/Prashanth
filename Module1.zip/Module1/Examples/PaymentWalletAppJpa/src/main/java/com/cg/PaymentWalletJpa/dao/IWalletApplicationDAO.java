package com.cg.PaymentWalletJpa.dao;

import java.util.List;

import com.cg.PaymentWalletJpa.dto.Customer;

public interface IWalletApplicationDAO {
	public void beginTransaction();

	public void commitTransaction();

	public int createAccount(Customer details);

	public Customer login(String username, String password);

	public double showBalance(String phoneNo);

	public int deposit(String phoneNo, double amount);

	public int withdraw(String phoneNo, double amount);

	public int fundTransfer(String senderphoneNo, String recieverphoneNo, double amount);

	public List printTrans();

}
