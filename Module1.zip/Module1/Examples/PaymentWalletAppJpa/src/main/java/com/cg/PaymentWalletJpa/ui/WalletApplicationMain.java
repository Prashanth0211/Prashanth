package com.cg.PaymentWalletJpa.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.PaymentWalletJpa.dto.Customer;
import com.cg.PaymentWalletJpa.dto.Wallet;
import com.cg.PaymentWalletJpa.exception.IWalletException;
import com.cg.PaymentWalletJpa.exception.WalletException;
import com.cg.PaymentWalletJpa.service.IWalletApplicationService;
import com.cg.PaymentWalletJpa.service.WalletApplicationServiceImpl;

public class WalletApplicationMain {

	public static void main(String[] args) {
		IWalletApplicationService service = new WalletApplicationServiceImpl();
		Scanner scr = new Scanner(System.in);
		List<String> trans = new ArrayList<String>();
		int key = 0;
		System.out.println("***Welcome to Payment Wallet Application***");
		do {
			System.out.println("1.CreateAccount\n2.Login\n3.Exit");
			System.out.println("Enter choice");
			try {
				key = scr.nextInt();
				switch (key) {
				case 1:
					try {
						System.out.println("Enter Name: ");
						String name = scr.next();
						System.out.println("Enter  gender(Male/Female): ");
						String gender = scr.next();
						System.out.println("Enter Mobile Number: ");
						String mobileNo = scr.next();
						System.out.println("Enter age: ");
						int age = scr.nextInt();
						System.out.println("Enter email: ");
						String email = scr.next();
						System.out.println("Enter UserName: ");
						String username = scr.next();
						System.out.println("Enter password of minimum length 8");
						String password = scr.next();
						System.out.println("Enter minimum amount");
						double amount = scr.nextDouble();
						LocalDate date = LocalDate.now();
						Customer customer = new Customer();
						Wallet details = new Wallet();
						customer.setName(name);
						customer.setGender(gender);
						customer.setMobileNo(mobileNo);
						customer.setAge(age);
						customer.setEmail(email);
						customer.setUsername(username);
						customer.setPassword(password);
						details.setAmount(amount);

						details.setDate(date);
						customer.setWallet(details);
						boolean result = false;
						try {
							result = service.validationDetails(customer);
						} catch (WalletException stException) {
							System.out.println(stException.getMessage());
						}
						if (result) {
							int value=service.createAccount(customer);
							if(value==1)
							{
							System.out.println("Your Account has been created");
							}
							else {
								System.out.println("account not created");
							}

						} else {
							System.out.println("Enter Valid Details");
						}

					} catch (Exception e) {
						//System.out.println(e.getMessage());
						e.printStackTrace();
					}

					break;
				case 2:
					int choice = 0;
					Scanner scr1 = new Scanner(System.in);

					try {
						System.out.println("Enter username");
						String username = scr.next();
						System.out.println("Enter password");
						String password = scr.next();
						

						if (service.login(username, password) != null) {
							System.out.println("LoggedIn succesfully");
							do {
								System.out.println(
										"1.ShowBalance\n2.Deposit\n3.Withdraw\n4.FundTransfer\n5.PrintTransactions\n6.Exit the Application");
								System.out.println("Enter your choice");
								choice = scr.nextInt();
								switch (choice) {
								case 1:
									System.out.println("Enter phone number");
									String mobile = scr.next();
									System.out.println("Your Account Balance is :" + service.showBalance(mobile));
									break;
								case 2:
									System.out.println("Enter phone number");
									String mobile1 = scr.next();
									System.out.println("Enter the amount to deposite");
									double amount = scr.nextDouble();
									service.deposit(mobile1, amount);
									break;
								case 3:
									System.out.println("Enter phone number");
									String mobile2 = scr.next();
									System.out.println("Enter the amount to withdraw");
									double with_amt = scr.nextDouble();
									service.withdraw(mobile2, with_amt);

									break;
								case 4:
									System.out.println("Enter number of sender");
									String sender = scr.next();
									System.out.println("Enter number of reciever");
									String reciever = scr.next();
									System.out.println("Enter amount to transfer");
									double tran_amt = scr.nextDouble();
									service.fundTransfer(sender, reciever, tran_amt);
									break;
								case 5:
									System.out.println(service.printTrans());
									break;
								case 6:
									System.exit(0);
									break;
								default:

									System.out.println("Enter valid choice");
									break;
								}
							} while (choice != 6);
						} else {
							try {
								throw new WalletException(IWalletException.ERROR4);
							} catch (Exception e) {
								System.out.println(e.getMessage());
							}
						}

					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 3:
					System.exit(0);
					break;

				default:
					System.out.println("Enter correct choice");
					break;
				}
			} catch (NumberFormatException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} while (key != 3);

	}

}
