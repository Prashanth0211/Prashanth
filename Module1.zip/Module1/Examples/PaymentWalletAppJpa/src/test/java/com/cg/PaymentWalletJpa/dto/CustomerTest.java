package com.cg.PaymentWalletJpa.dto;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {

	Customer cust = new Customer();

	public void testGetWallet() {

	}

	public void testGetCustomerName() {
		cust.setName("Prashanth");
		assertEquals("Prashanth", cust.getName());
	}

	public void testGetPhoneNumber() {
		cust.setMobileNo("7660824282");
		assertEquals("7660824282", cust.getMobileNo());

	}

	public void testGetGender() {
		cust.setGender("male");
		assertEquals("male", cust.getGender());
	}

	public void testGetAge() {
		cust.setAge(22);
		assertEquals(22, cust.getAge());

	}

	public void testGetUser_ID() {
		cust.setUsername("Prashanth11");
		assertEquals("Prashanth11", cust.getUsername());
	}

	public void testGetPassword() {
		cust.setPassword("Prashanth@11");
		assertEquals("Prashanth@11", cust.getPassword());

	}

}
