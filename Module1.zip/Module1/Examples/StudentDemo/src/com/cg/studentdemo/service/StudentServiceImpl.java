package com.cg.studentdemo.service;

import java.util.HashSet;

import com.cg.studentdemo.dao.IStudentDao;
import com.cg.studentdemo.dao.StudentDaoImpl;
import com.cg.studentdemo.dto.StudentDto;

public class StudentServiceImpl implements IStudentService {

	IStudentDao dao=new StudentDaoImpl();
	@Override
	public void addStudent(StudentDto dto) {
		// TODO Auto-generated method stub
		dao.addStudent(dto);
	}

	@Override
	public HashSet<StudentDto> showAllDetails() {
		// TODO Auto-generated method stub
		return dao.showAllDetails();
	}

	@Override
	public StudentDto searchStudent(int sid) {
		// TODO Auto-generated method stub
		return dao.searchStudent(sid);
	}

	@Override
	public void removeStudent(int rid) {
		// TODO Auto-generated method stub
		dao.removeStudent(rid);
	}

	@Override
	public void updateStudent(StudentDto update) {
		// TODO Auto-generated method stub
		dao.updateStudent(update);
	}

}
