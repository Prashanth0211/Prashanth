package com.cg.studentdemo.dao;

import java.util.HashSet;
import java.util.Iterator;

import com.cg.studentdemo.dto.StudentDto;

public class StudentDaoImpl implements IStudentDao {

	private static HashSet<StudentDto> myHash=null;
	static {
		
		myHash=new HashSet<>();
	}
	@Override
	public int addStudent(StudentDto dto){
		int generateId=(int) (Math.random()*10000);
		dto.setStuId(generateId);
		myHash.add(dto);
		return generateId;
	}
	@Override
	public HashSet<StudentDto> showAllDetails() {
		// TODO Auto-generated method stub
		return myHash;
	}
	@Override
	public StudentDto searchStudent(int sid) {
		// TODO Auto-generated method stub
		StudentDto ssearch = null;
		for(StudentDto student:myHash) {
			if(student.getStuId()==sid) {
				ssearch=student;
				break;
			}
		}
		return ssearch;

	}
	@Override
	public void removeStudent(int rid) {
		// TODO Auto-generated method stub
		Iterator<StudentDto> it= myHash.iterator(); 
		while(it.hasNext()) {
			StudentDto studentDto= (StudentDto) it.next();
			it.remove();
			}
		}
	@Override
	public void updateStudent(StudentDto update) {
		// TODO Auto-generated method stub
		Iterator<StudentDto> it=myHash.iterator();
		while(it.hasNext()) {
			StudentDto dto=it.next();
			if(dto.getStuId()==update.getStuId()) {
				dto.setStuName(update.getStuName());
				dto.setPassOut(update.getPassOut());
			}
		}
	}	

	}
	
	
	

