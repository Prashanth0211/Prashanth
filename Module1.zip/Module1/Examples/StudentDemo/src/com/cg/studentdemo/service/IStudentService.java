package com.cg.studentdemo.service;

import java.util.HashSet;
import java.util.List;

import com.cg.studentdemo.dto.StudentDto;

public interface IStudentService {

	public void addStudent(StudentDto dto);

	public HashSet<StudentDto> showAllDetails();
	
	public StudentDto searchStudent(int sid);
	
	public void removeStudent(int rid);
	
	public void updateStudent(StudentDto update);
}
