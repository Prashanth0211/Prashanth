package com.cg.studentdemo.dao;

import java.util.HashSet;

import com.cg.studentdemo.dto.StudentDto;

public interface IStudentDao {

	public int addStudent(StudentDto dto);

	public HashSet<StudentDto> showAllDetails();
	
	public StudentDto searchStudent(int sid);
	
	public void removeStudent(int rid);
	
	public void updateStudent(StudentDto update);
}
