package com.cg.eis.pl;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public Employee showDetails(Employee employee) {
		// TODO Auto-generated method stub
		return employee;
	}

}
