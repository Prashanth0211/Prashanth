package com.cg.eis.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.pl.EmployeeService;
import com.cg.eis.pl.EmployeeServiceImpl;

public class MyMain {

	public static void main(String[] args) {

		Scanner scr = new Scanner(System.in);
		System.out.println("Enter Id:");
		int eid = scr.nextInt();
		System.out.println("Enter Name:");
		String ename = scr.next();
		System.out.println("Enter salary:");
		double esal = scr.nextDouble();

		Employee emp = new Employee();
		emp.setId(eid);
		emp.setName(ename);
		emp.setSalary(esal);

		if (esal > 5000 && esal < 20000) {
			emp.setDesignation("System Associate");
			emp.setInsuranceScheme("Scheme C");
		} else if (esal >= 20000 && esal < 40000) {
			emp.setDesignation("Programmer");
			emp.setInsuranceScheme("Scheme B");
		} else if (esal >= 4000) {
			emp.setDesignation("Manager");
			emp.setInsuranceScheme("Scheme A");
		} else if (esal < 5000) {
			emp.setDesignation("Clerk");
			emp.setInsuranceScheme("No Scheme");
		}

		EmployeeService service = new EmployeeServiceImpl();
		Employee employee = service.showDetails(emp);
		System.out.println("All Details are: ");
		System.out.println("Employee ID: " + employee.getId());
		System.out.println("Employee Name: " + employee.getName());
		System.out.println("Employee Salary: " + employee.getSalary());
		System.out.println("Employee Designation: " + employee.getDesignation());
		System.out.println("Employee InsuranceScheme: " + employee.getInsuranceScheme());

		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("source.txt")));
			oos.writeObject(emp);
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			System.out.println("Writing Failed");
		}

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("source.txt")));
			try {
				System.out.println("Deserialization");
				Employee oemployee = (Employee) ois.readObject();
				System.out.println("All Details are: ");
				System.out.println("Employee ID: " + oemployee.getId());
				System.out.println("Employee Name: " + oemployee.getName());
				System.out.println("Employee Salary: " + oemployee.getSalary());
				System.out.println("Employee Designation: " + oemployee.getDesignation());
				System.out.println("Employee InsuranceScheme: " + oemployee.getInsuranceScheme());
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			System.out.println("Reading Failed");
		}
	}

}
