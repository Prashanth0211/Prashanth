package com.cg.eis.pl;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	public abstract Employee showDetails(Employee employee);
}
