package com.cg;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MyMain {

	public static void main(String[] args) throws IOException {

		FileReader fileReader=new FileReader(new File("source.txt"));
		FileWriter fileWriter=new FileWriter(new File("target.txt"));
		StringBuilder sb=new StringBuilder();
		int data;
		while((data=fileReader.read())!=-1) {
			sb.append((char)data);
		}
		fileReader.close();
		fileWriter.write(sb.reverse().toString());
		System.out.println("File Copied");
		fileWriter.close();
	}

}
