package com.cg.demoeight.ui;

import java.util.Scanner;

import com.cg.demoeight.dto.Employee;

public class MyMainApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scr=new Scanner(System.in);
		
		System.out.println("enter the employee id ");
		int id=scr.nextInt();
		
		System.out.println("enter the employee name ");
		String ename=scr.next();

		System.out.println("enter the employee salary ");
		double esal=scr.nextDouble();

Employee emp=new Employee();

emp.setEmpId(id);
emp.setEmpName(ename);
emp.setEmpSalary(esal);

System.out.println(emp);
	}

}
