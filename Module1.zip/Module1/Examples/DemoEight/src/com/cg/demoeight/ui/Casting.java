package com.cg.demoeight.ui;


import java.util.Scanner;
public class Casting {

	public static void main(String[] args) {
		
		
		String str="Capgemini";
		//System.out.println(str.length());
		
		//System.out.println(str.substring(3));
		
		//System.out.println(str.concat(" IGate"));
		
		//System.out.println(str.replace("i","g"));
		
		String str1="Capgemini";
		
		if(str.equals(str1)) {
			System.out.println("True");
		}
		else {
			System.out.println("False");
		}
		
		}
}
