package com.cg.demoeight.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		//LocalDateTime today=LocalDateTime.now();
      
       //System.out.println(today);
       
       //LocalDate myDate=LocalDate.of(2017,Month.APRIL,17);
       //System.out.println(myDate.getMonth());
       //System.out.println(today);
		//ZonedDateTime zoneIndia=ZonedDateTime.now();
		//System.out.println(zoneIndia);
		
		//ZonedDateTime zoneFrance=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		//System.out.println(zoneFrance);
	//LocalDate today=LocalDate.now();
	//LocalDate joinDate=LocalDate.of(2014, Month.JULY, 13);
	//Period diff=joinDate.until(today);
	//System.out.println("Exp in no of Years "+diff.getYears());
	//System.out.println("Exp in no of Months "+diff.getMonths());
	//System.out.println("Exp in no of Days "+diff.getDays());
	DateTimeFormatter formate=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	Scanner scr=new Scanner(System.in);
	System.out.println("Enter the Date in dd/mm/yyyy");
	String date=scr.next();
	LocalDate myDate=LocalDate.parse(date,formate);
	System.out.println("Date is "+myDate);
	
	
	}

}
