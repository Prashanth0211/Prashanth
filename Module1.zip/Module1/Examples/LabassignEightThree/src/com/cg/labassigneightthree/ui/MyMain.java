package com.cg.labassigneightthree.ui;

import java.util.Random;

public class MyMain extends Thread {

	static int num=0;
	public void run() {
		try {
			Random random=new Random();
			num=Math.abs(random.nextInt(5));
			System.out.println("Number : "+num);
		} catch (Exception e) {
			System.out.println("Error : "+e);
		}
	}
	public static void main(String[] args) {
		
		MyMain m1=new MyMain();
		m1.start();
		
		FactThread ft=new FactThread(num);
		ft.start();
	}
}
