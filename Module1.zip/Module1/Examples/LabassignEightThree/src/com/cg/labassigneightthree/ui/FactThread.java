package com.cg.labassigneightthree.ui;

public class FactThread extends Thread {
	int num;

	public FactThread(int num) {
		super();
		this.num = num;
	}

	public void run() {
		long fact = 1;
		for (int i = 1; i <= num; i++) {
			fact *= i;
		}
		Thread t = new Thread();
		t.setName("Prashanth");
		System.out.println("Factorial of " + num + ":" + fact);
	}
}
