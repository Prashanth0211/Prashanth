package com.cg.newdemoone.dto;

public class Project {
	
	private int projId;
	private String projName;
	
	public Project() {
		}
	public Project(int projId, String projName) {
		super();
		this.projId = projId;
		this.projName = projName;
	}
	public int getProjId() {
		return projId;
	}
	public void setProjId(int prjId) {
		this.projId = prjId;
	}
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}

}
