package com.cg.labassignthreeone.ui;

import java.util.Scanner;

public class MyMain {
static String str;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1;
Scanner scr=new Scanner(System.in);
System.out.println("Enter the string");
str1=scr.nextLine();
str=str1;

int i=0;
while(str1!=null && i<1) {

menu();
i++;

	}

}

public static void menu() {

	int choice;
	Scanner scr=new Scanner(System.in);
	System.out.println("Choose from these choices");
	System.out.println("_________________________");
	System.out.println("1.Add the string to itself");
	System.out.println("2.Replace odd positions with #");
	System.out.println("3.Remove duplicate characters in the string");
	System.out.println("4.Change odd characters to uppercase");
	System.out.println("5.Quit");
	choice=scr.nextInt();
	switch(choice) {
	case 1:first();break;
	case 2:second();break;
	case 3:third();break;
	case 4:fourth();break;
	default :System.exit(0);
	}
}
public static void first() {
	
	System.out.println("The resultant string is: "+str.concat(str));
menu();
	
   }

public static void second() {
	StringBuilder sb=new StringBuilder(str);
	int count=0;
	for(int i=0;i<sb.length();i++) {
		char currChar=sb.charAt(i);
		if(count++ %2 ==1) {
			sb.setCharAt(i, '#');
		}
	}
	System.out.println("The resultant string is: "+sb.toString());
	menu();
}

public static void third() {
	String newstr="";
	for(int i=0;i<str.length();i++) {
		if(!newstr.contains(String.valueOf(str.charAt(i)))) {
			newstr+=String.valueOf(str.charAt(i));
		}
	}
	System.out.println("The resultant string is: "+newstr);
	menu();
}

public static void fourth() {
	String newstr="";
	for(int i=0;i<str.length();i++) {
		if(i%2!=0) {
			char ch=str.charAt(i);
			newstr+=String.valueOf(ch).toUpperCase();
		}
		else
			newstr+=str.charAt(i);
	}
	System.out.println("The resultant string is: "+newstr);
	menu();
    }

}