package com.cg.sample.ui;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
