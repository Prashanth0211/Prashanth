package com.cg.service;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class LoginServiceImplTest {
	private static ILoginService service = null;
	static {
		service = new LoginServiceImpl();
	}

	@Test
	public void testForBlankInputs() {
		System.out.println("i");

		boolean output = service.login("", "");
		assertFalse(output);
	}

	@Test
	public void testForBlankPassword() {
		System.out.println("pw");

		boolean output = service.login("admin", "");
		assertFalse(output);
	}

	@Test
	public void testForBlankUserName() {
		System.out.println("un");

		boolean output = service.login("", "admin");
		assertFalse(output);
	}

	@Test(expected = NullPointerException.class)
	public void display() {
		String output = service.display("psn");
		assertNotNull(output);
	}
}
