package com.cg;

import java.util.Queue;
import java.util.Random;

public class BillerThread implements Runnable {

	private Queue sharedQ;
	private final int MAX_SIZE;

	public BillerThread(Queue sharedQ, int MAX_SIZE) {
		super();
		this.sharedQ = sharedQ;
		this.MAX_SIZE = MAX_SIZE;
	}

	@Override
	public void run() {

		while (true) {
			synchronized (sharedQ) {
				while (sharedQ.isEmpty()) {
					try {
						System.out.println("Billing Completed");
						sharedQ.wait();
					} catch (Exception e) {
						System.out.println("Error: " + e);
					}
				}

				System.out.println("Product: " + sharedQ.remove());

				sharedQ.notify();
			}

		}

	}

}
