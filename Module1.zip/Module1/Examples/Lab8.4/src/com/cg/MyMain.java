package com.cg;

import java.util.LinkedList;
import java.util.Queue;

public class MyMain {

	public static void main(String[] args) {

		Queue sharedQ = new LinkedList();
		final int MAX_SIZE = 5;
		Thread customer = new Thread(new CustomerThread(sharedQ, MAX_SIZE));
		Thread biller = new Thread(new BillerThread(sharedQ, MAX_SIZE));
		customer.start();
		biller.start();
	}

}
