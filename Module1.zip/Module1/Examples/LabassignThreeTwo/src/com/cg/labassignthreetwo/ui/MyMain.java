package com.cg.labassignthreetwo.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner scr=new Scanner(System.in);
     System.out.println("Enter String ");
     String str=scr.nextLine();
     System.out.println(order(str.toLowerCase()));
     

	}
public static boolean order(String str) {
	
	for(int i=0;i<str.length()-1;i++) {
		if(str.charAt(i)>str.charAt(i+1))
			return false;
	}
	
	return true;
}
}
