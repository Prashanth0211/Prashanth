package com.cg;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student std = new Student();
		std.setName("sai");
		std.setId(1234);
		System.out.println(std.getName());
		System.out.println(std.getId());

	}

}
