package com.cg.labassignfivethree.service;

public class AccountInheritance extends Account {

	@Override
	public void Deposit(double amount) {
		// TODO Auto-generated method stub
		balance=balance+amount;	
	}

	@Override
	public void Withdraw(double amount) {
		// TODO Auto-generated method stub
		balance=balance-amount;
	}

	
}
