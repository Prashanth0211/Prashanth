package com.cg.labassignfivethree.service;

import com.cg.labassignfivethree.service.Person;

public abstract class Account {

	private long accNum;
	protected double balance;
	Person per;
	
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Person getPer() {
		return per;
	}
	public void setPer(Person per) {
		this.per = per;
	}
	public abstract void Deposit(double amount);
	public abstract void Withdraw(double amount); 
    	
	public double getBal() {
		return balance;
	}
}
