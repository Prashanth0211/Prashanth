package com.cg.labassigneightone.ui;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread implements Runnable {

	FileInputStream fileInputStream;
	FileOutputStream fileOutputStream;

	public CopyDataThread(FileInputStream fileInputStream, FileOutputStream fileOutputStream) {
		super();
		this.fileInputStream = fileInputStream;
		this.fileOutputStream = fileOutputStream;
	}

	@Override
	public void run() {
		int c = 0;
		int count = 0;
		try {
			while ((c = fileInputStream.read()) != -1) {
				try {
					fileOutputStream.write((char) c);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				count++;
				if (count == 10) {
					System.out.println("10 character copied");
					try {
						count = 0;
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try {
			fileInputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			fileOutputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
