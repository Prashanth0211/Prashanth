package com.cg.labassigneightone.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileProgram {

	public static void main(String[] args) throws FileNotFoundException {

		FileInputStream fileInputStream = new FileInputStream(new File("source.txt"));
		FileOutputStream fileOutputStream = new FileOutputStream(new File("target.txt"));
		Thread thread = new Thread(new CopyDataThread(fileInputStream, fileOutputStream));
		thread.start();
	}

}
