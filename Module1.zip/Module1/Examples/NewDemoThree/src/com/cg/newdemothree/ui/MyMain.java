package com.cg.newdemothree.ui;

import com.cg.newdemothree.service.Outer;
import com.cg.newdemothree.service.Outer.Inner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer out = new Outer();
		out.showData();
		Inner in = new Inner();
		in.getData();
	}

}
