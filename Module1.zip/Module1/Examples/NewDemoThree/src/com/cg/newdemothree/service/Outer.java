package com.cg.newdemothree.service;

public class Outer {

	public static class Inner {
		public void getData() {
			System.out.println("In Inner Class.....");
		}
	}

	public void showData() {
		System.out.println("In Outer Class.....");
	}
}
