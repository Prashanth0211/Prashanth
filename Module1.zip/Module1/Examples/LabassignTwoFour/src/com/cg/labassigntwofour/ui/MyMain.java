package com.cg.labassigntwofour.ui;



public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonMain per=new PersonMain();
		per.setFirstName("Prashanth");
		per.setLastName("Nichenametla");
		per.setGender("Male");
		System.out.println("PersonDetails: ");
		System.out.println("_______________");
		System.out.println("FirstName: "+per.getFirstName());
		System.out.println("LastName: "+per.getLastName());
		System.out.println("Gender: "+per.getGender());
		System.out.println("Phone Number: "+per.PersonDetails(args[0]));
	}

}
