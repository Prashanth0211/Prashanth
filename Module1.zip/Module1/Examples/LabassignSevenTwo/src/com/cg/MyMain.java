package com.cg;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class MyMain {

	public static void main(String[] args) {

		String str1, str2;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter first String");
		str1 = scanner.next();
		System.out.println("Enter Second String");
		str2 = scanner.next();
		performOperation(str1, str2);
	}

	private static void performOperation(String str1, String str2) {
		List<String> list = new ArrayList<>();

		int countOne = 0;
		char c[] = str2.toCharArray();
		StringBuilder myName = new StringBuilder(str1);
		StringBuilder myName1 = new StringBuilder(str2);
		for (int i = 0; i < str1.length(); i++) {
			if (i % 2 == 0) {
				myName.setCharAt(i, c[countOne++]);
			}
		}
		System.out.println("After first Operation " + myName);
		list.add(myName.toString());
		str1 = myName.toString();

		int countTwo = 0, idx = 0;
		while ((idx = str1.indexOf(str2, idx)) != -1) {
			idx++;
			countTwo++;
		}
		if (countTwo > 1) {
			int lastIndex = str1.lastIndexOf(myName.toString());
			StringBuilder sb = new StringBuilder();
			sb.append(str1.substring(0, lastIndex));
			sb.append(myName1.toString());
			sb.append(str1.substring(0, lastIndex + str2.length()));
			str1 = sb.toString();
		} else
			str1 += str2;
		System.out.println("After second operation " + str1);
		list.add(str1);

		int countThree = 0, idx1 = 0;
		while ((idx1 = str1.indexOf(str2, idx1)) != -1) {
			idx1++;
			countThree++;
		}
		if (countThree > 1) {
			str1 = str1.replaceFirst(Pattern.quote(str2 + ""), "");
		}
		list.add(str1);
		System.out.println("After third operation " + str1);

		String part1, part2;
		part1 = str2.substring(0, str2.length() / 2);
		part2 = str2.substring(str2.length() / 2, str2.length());
		str1 = part1 + str1;
		str1 = str1.concat(part2);
		System.out.println("After fourth operation " + str1);

		char cv[] = str1.toCharArray();
		char cv1[] = str2.toCharArray();
		for (int j = 0; j < cv1.length; j++) {
			for (int j2 = 0; j2 < cv.length; j2++) {
				if (cv1[j] == cv[j2]) {
					cv[j2] = '*';
				}
			}
		}

		list.add(String.valueOf(cv));

		System.out.println("After fifth operation " + String.valueOf(cv));
		System.out.println("Finally the ArratList is :" + list);

	}

}
