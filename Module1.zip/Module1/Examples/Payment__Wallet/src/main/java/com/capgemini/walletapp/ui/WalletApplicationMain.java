package com.capgemini.walletapp.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.walletapp.bean.Customer;
import com.capgemini.walletapp.bean.WalletApplication;
import com.capgemini.walletapp.exception.IWalletException;
import com.capgemini.walletapp.exception.WalletException;
import com.capgemini.walletapp.service.WalletApplicationService;

public class WalletApplicationMain {

	public static void createAccount() {
		WalletApplicationService service = new WalletApplicationService();
		List<String> trans = new ArrayList<String>();
		Scanner scr = new Scanner(System.in);

		try {
			System.out.println("Enter Name: ");
			String name = scr.next();
			System.out.println("Enter  gender(Male/Female): ");
			String gender = scr.next();
			System.out.println("Enter Mobile Number: ");
			String mobileNo = scr.next();
			System.out.println("Enter age: ");
			int age = scr.nextInt();
			System.out.println("Enter email: ");
			String email = scr.next();
			System.out.println("Enter UserName: ");
			String username = scr.next();
			System.out.println("Enter password of minimum length 8");
			String password = scr.next();
			System.out.println("Enter minimum amount");
			double amount = scr.nextDouble();
			LocalDate date = LocalDate.now();
			long accNo = (long) (Math.random() * 123456789 + 999999999);
			Customer data = new Customer();
			WalletApplication details = new WalletApplication();
			data.setName(name);
			data.setGender(gender);
			data.setMobileNo(mobileNo);
			data.setAge(age);
			data.setEmail(email);
			data.setUsername(username);
			data.setPassword(password);
			details.setAmount(amount);
			details.setAccNo(accNo);
			details.setTrans(trans);
			details.setCust(data);
			details.setDate(date);

			boolean result = false;
			try {
				result = service.validationDetails(data);
			} catch (WalletException stException) {
				System.out.println(stException.getMessage());
			}
			if (result) {
				service.createAccount(details);
				System.out.println("Your Account has been created");
				System.out.println("Account No is :" + details.getAccNo());
			} else {
				System.out.println("Enter Valid Details");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void login() {
		int choice = 0;
		Scanner scr = new Scanner(System.in);
		WalletApplicationService service = new WalletApplicationService();

		try {
			System.out.println("Enter username");
			String username = scr.next();
			System.out.println("Enter password");
			String password = scr.next();

			if (service.login(username, password)) {
				System.out.println("LoggedIn succesfully");
				do {
					System.out.println(
							"1.ShowBalance\n2.Deposit\n3.Withdraw\n4.FundTransfer\n5.PrintTransactions\n6.Exit the Application");
					System.out.println("Enter your choice");
					choice = scr.nextInt();
					switch (choice) {
					case 1:
						System.out.println("Your Account Balance is :" + service.showBalance());
						break;
					case 2:
						System.out.println("Enter the amount to deposite");
						double amount = scr.nextDouble();
						service.deposit(amount);
						break;
					case 3:
						System.out.println("Enter the amount to withdraw");
						double with_amt = scr.nextDouble();
						service.withdraw(with_amt);

						break;
					case 4:
						System.out.println("Enter any accountNo. for MoneyTransfer");
						long accNo = scr.nextLong();
						System.out.println("Enter amount to transfer");
						double tran_amt = scr.nextDouble();
						service.fundTransfer(accNo, tran_amt);
						break;
					case 5:
						System.out.println(service.printTrans());
						break;
					case 6:
						mainMenu();
						break;
					default:

						System.out.println("Enter valid choice");
						break;
					}
				} while (choice != 6);
			} else {
				try {
					throw new WalletException(IWalletException.ERROR4);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void mainMenu() {
		int key = 0;
		Scanner scr = new Scanner(System.in);
		System.out.println("***Welcome to Payment Wallet Application***");
		do {
			System.out.println("1.CreateAccount\n2.Login\n3.Exit");
			System.out.println("Enter choice");
			try {
				key = scr.nextInt();
				switch (key) {
				case 1:
					createAccount();
					break;
				case 2:
					login();
					break;
				case 3:
					System.exit(0);
					break;

				default:
					System.out.println("Enter correct choice");
					break;
				}
			} catch (NumberFormatException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} while (key != 3);

	}

	public static void main(String[] args) {

		mainMenu();

	}

}
