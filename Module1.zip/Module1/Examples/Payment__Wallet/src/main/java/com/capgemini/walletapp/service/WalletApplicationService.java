package com.capgemini.walletapp.service;

import java.util.List;
import java.util.Map;

import com.capgemini.walletapp.bean.Customer;
import com.capgemini.walletapp.bean.WalletApplication;
import com.capgemini.walletapp.dao.WalletApplicationDAO;
import com.capgemini.walletapp.exception.IWalletException;
import com.capgemini.walletapp.exception.WalletException;

public class WalletApplicationService implements IWalletApplicationService {

	WalletApplicationDAO dao = new WalletApplicationDAO();

	public int createAccount(WalletApplication details) {

		return dao.createAccount(details);
	}

	public boolean login(String username, String password) {

		return dao.login(username, password);
	}

	public double showBalance() {

		return dao.showBalance();
	}

	public int deposit(double amount) {

		return dao.deposit(amount);
	}

	public int withdraw(double amount) {

		return dao.withdraw(amount);
	}

	public int fundTransfer(long accNo, double amount) {

		return dao.fundTransfer(accNo, amount);
	}

	public List printTrans() {

		return dao.printTrans();
	}

	public boolean validationDetails(Customer customer) throws WalletException {
		boolean result = false;

		if (customer.getName().matches("[A-Z]{1}[a-z]+")) {
			if (customer.getMobileNo().matches("[0-9]{10}")) {
				if (customer.getEmail().matches("[a-zA-Z0-9_]*@gmail.com")) {
					if (!(customer.getUsername().equals(customer.getPassword()))) {
						if (customer.getUsername().matches("[A-Za-z0-9]{4,}")) {
							if (customer.getPassword().length() >= 8) {
								result = true;
							} else
								throw new WalletException(IWalletException.ERROR7);
						} else
							throw new WalletException(IWalletException.ERROR6);
					} else
						throw new WalletException(IWalletException.ERROR5);
				} else
					throw new WalletException(IWalletException.ERROR3);
			} else
				throw new WalletException(IWalletException.ERROR2);
		} else
			throw new WalletException(IWalletException.ERROR1);

		return result;
	}

}
