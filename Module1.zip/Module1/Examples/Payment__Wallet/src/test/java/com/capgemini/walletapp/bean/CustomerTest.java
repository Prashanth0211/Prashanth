package com.capgemini.walletapp.bean;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {
	
	Customer data=new Customer();

	public void testGetFirstName() {
		data.setName("Prashanth");
		assertEquals("Prashanth",data.getName());
		assertTrue("Prashanth".equalsIgnoreCase(data.getName()));
		assertNotNull(data);
	}

	public void testGetGender() {
		data.setGender("Male");
		assertEquals("Male",data.getGender());
	}

	public void testGetMobileNo() {
		data.setMobileNo("7660824282");
		assertEquals("7660824282",data.getMobileNo());
		
	}

	public void testGetAge() {
		data.setAge(21);
		assertEquals(21,data.getAge());
	}

	public void testGetEmail() {
		data.setEmail("prashanthpsn1995@gmail.com");
		assertEquals("prashanthpsn1995@gmail.com",data.getEmail());
		
	}

	public void testGetUsername() {
		data.setUsername("Prashanth11");
		assertEquals("Prashanth11",data.getUsername());
		
	}

	public void testGetPassword() {
		data.setPassword("Psn@1234");
		assertEquals("Psn@1234",data.getPassword());
		
	}

}
