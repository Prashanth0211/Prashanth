package com.cg.labassignfourone.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.labassignfourone.service.Account;
import com.cg.labassignfourone.service.Person;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner scr=new Scanner(System.in);
		Random rand=new Random();
		
		System.out.println("Enter Account Holder name");
		String pname=scr.next();
		System.out.println("Enter Person age");
		float page=scr.nextFloat();
		System.out.println("Enter balance");
		double balance=scr.nextDouble();
		 
		Person per=new Person();
		per.setName(pname);
		per.setAge(page);
		
		Account acc=new Account();
		acc.setAccNum(rand.nextLong());
		acc.setBalance(balance);
		acc.setPer(per);
		String acc1=per.getName();
		
		System.out.println("Account Number is: "+acc.getAccNum());
		System.out.println("Balance is       : "+acc.getBalance());
		System.out.println("Account Holder Name is: "+acc.getPer().getName());
		System.out.println("Account Holder Age  is: "+acc.getPer().getAge());
		
		if(acc1.equals("Kathy")) {
			System.out.println("Withdrawn from Kathy Account "+acc.Withdraw(2000)+"Balance Available "+acc.getBalance());
		}
		else if(acc1.equals("Smith")) {
			System.out.println("Deposit to Smith Account "+acc.Deposit(2000)+"Balance Available "+acc.getBalance());
		}
	}

}
