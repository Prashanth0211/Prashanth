package com.cg.labassignfourone.service;

public class Account {

	private long accNum;
	private double balance;
	Person per;
	
	public Account() {	
	}
	
	public Account(long accNum, double balance) {
		super();
		this.accNum = accNum;
		this.balance = balance;
	}


	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Person getPer() {
		return per;
	}
	public void setPer(Person per) {
		this.per = per;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance + ", per=" + per + "]";
	}
	public double Deposit(double amount) {
		balance=balance+amount;
		return balance;
	}
    public double Withdraw(double amount) {
    	balance=balance-amount;
    	return balance;
    }
}
