package com.cg.labassignthreeseven.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String name;
Scanner scr=new Scanner(System.in);
System.out.println("Enter the name like acbd_job");
name=scr.nextLine();
if(name.length()>=12) {
if(name.substring(name.length()-4,name.length()).equalsIgnoreCase("_job"))
    
	System.out.println("True");
else 
	System.out.println("False");
    }

else 
System.out.println("False");
	

	}
}

	


