package com.cg;

@FunctionalInterface
public interface ILogin {
	boolean validate(String user, String password);
}
