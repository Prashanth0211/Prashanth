package com.cg;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ILogin log = (username, password) -> {
			boolean result = false;
			if (username == "Admin" && password == "Admin") {
				result = true;
			}
			return result;

		};
		System.out.println(log.validate("Admin", "Admin"));
		System.out.println(log.validate("user", "password"));
	}
}
