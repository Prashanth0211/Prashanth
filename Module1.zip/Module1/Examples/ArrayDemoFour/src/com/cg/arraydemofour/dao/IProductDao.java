package com.cg.arraydemofour.dao;

import java.util.List;

import com.cg.arraydemofour.dto.Product;

public interface IProductDao {

	
	public void addProductDao(Product Pro);
	public List<Product >showAllProductDao();
	public Product searchProduct(int pid);
	public void removeProduct(int prorId);
	
}
