package com.cg.arraydemofour.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.arraydemofour.dto.Product;

public class ProductDaoImpl implements IProductDao {

	List<Product> myList=new LinkedList<>();
	@Override
	public void addProductDao(Product pro) {
		// TODO Auto-generated method stub
		myList.add(pro);
	}

	@Override
	public List<Product> showAllProductDao() {
		// TODO Auto-generated method stub
		return myList;
	}

	@Override
	public Product searchProduct(int pid) {
		// TODO Auto-generated method stub
		Product psearch = null;
		for(Product product:myList) {
			if(product.getProdId()==pid) {
				psearch=product;
				break;
			}
		}
		return psearch;
	}

	@Override
	public void removeProduct(int prorId) {
		// TODO Auto-generated method stub
		for(Product prod :myList) {
			if(prod.getProdId()==prorId) {
				myList.remove(prod);
				break;
			}
		}	
	}

}
