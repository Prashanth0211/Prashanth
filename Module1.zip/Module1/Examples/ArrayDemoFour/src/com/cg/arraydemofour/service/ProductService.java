package com.cg.arraydemofour.service;

import java.util.List;

import com.cg.arraydemofour.dao.IProductDao;
import com.cg.arraydemofour.dao.ProductDaoImpl;
import com.cg.arraydemofour.dto.Product;

public class ProductService implements IProductService {

	IProductDao dao=new ProductDaoImpl();
	@Override
	public void addProduct(Product pro) {
		// TODO Auto-generated method stub
		dao.addProductDao(pro);
	}

	@Override
	public List<Product> showAllProduct() {
		// TODO Auto-generated method stub
		return dao.showAllProductDao();
	}

	@Override
	public Product searchProduct(int prodid) {
		// TODO Auto-generated method stub
		return dao.searchProduct(prodid);
	}

	@Override
	public void removeProduct(int prorId) {
		// TODO Auto-generated method stub
		 dao.removeProduct(prorId);
	}

}
