package com.cg.arraydemofour.ui;


import java.util.List;
import java.util.Scanner;

import com.cg.arraydemofour.dto.Product;
import com.cg.arraydemofour.service.IProductService;
import com.cg.arraydemofour.service.ProductService;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      IProductService proservice=new ProductService(); 
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter choice");
			Scanner scr=new Scanner(System.in);
			choice=scr.nextInt();
			switch(choice) {
			case 1://Add
				System.out.println("Enter Product ID");
				int pid=scr.nextInt();
				System.out.println("Enter Product Name");
				String pname=scr.next();
				System.out.println("Enter Product Price");
				double pprice=scr.nextDouble();
				
				Product prod=new Product();
				prod.setProdId(pid);
				prod.setProdName(pname);
				prod.setProdPrice(pprice);
				
				proservice.addProduct(prod);
			    break;
			case 2://show
				List<Product> allData=proservice.showAllProduct();
				
				for(Product all:allData) {
					System.out.println("Product Id "+all.getProdId());
					System.out.println("Product Name "+all.getProdName());
					System.out.println("Product Price "+all.getProdPrice());
				}
				break;
			case 3://Search
				System.out.println("Enter Product Id..");
				int prodId=scr.nextInt();
				Product productSearch=proservice.searchProduct(prodId);
				
				if(productSearch==null) {
					System.out.println("Product Not Found");
				}
				else {
					System.out.println("Product Id "+productSearch.getProdId());
					System.out.println("Product Name "+productSearch.getProdName());
					System.out.println("Product Price "+productSearch.getProdPrice());
				}	
				break;
			case 4://remove
				System.out.println("Enter Product Id..");
				int rid=scr.nextInt();
				proservice.removeProduct(rid);
				break;
			case 5://Exit
				System.exit(0);
			    break;
			
		}
		}while(choice!=5);
	}	
		public static void printDetails() {
			System.out.println("1.Add Product ");
			System.out.println("2.Show All Product ");
			System.out.println("3.Search Product ");
			System.out.println("4.Remove Product");
			System.out.println("5.Exit");
		
		}
	

}
