package com.cg.labassigntwofive.ui;

enum Genders{Male("M"),Female("F");
	String gender;
	Genders(String g){
		this.gender=g;
	}
}

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Genders gen=null;
		System.out.print(gen.Male.gender);

	}

}
