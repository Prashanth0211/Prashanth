package com.cg.eis.bean;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.pl.EmployeeService;

public class Employee implements EmployeeService {

	int id;
	String name;
	double salary;
	String designation,insuranceScheme;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary(double salary){
		return salary;
	}
	public void setSalary(double salary) throws EmployeeException {
		if(salary<3000) {
			throw new EmployeeException("Salary is less than 3000");
		}
		else {
		this.salary = salary;
	}
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	@Override
	public void showDetails() {
		// TODO Auto-generated method stub
		System.out.println("All Details are: ");
		System.out.println("ID: "+getId());
		System.out.println("Name: "+getName());
		
		System.out.println("Designation: "+getDesignation());
		System.out.println("InsuranceScheme: "+getInsuranceScheme());
	}

}
