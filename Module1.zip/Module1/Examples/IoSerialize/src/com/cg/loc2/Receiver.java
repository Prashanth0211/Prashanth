package com.cg.loc2;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

import com.cg.loc1.Employee;

public class Receiver {

	public static void main(String[] args) throws Exception{

		File file= new File("D:\\Users\\learning\\Desktop\\test.txt");
		FileInputStream fis=new FileInputStream(file);
		ObjectInputStream ois=new ObjectInputStream(fis);
		Employee prashanth=(Employee) ois.readObject();
		System.out.println(prashanth.getEmpId()+" "+prashanth.getEmpName()+" "+prashanth.getEmpSal()+" "+prashanth.getEmpDesig());
		System.out.println(System.identityHashCode(prashanth));
		ois.close();
		fis.close();
		
	}
}
