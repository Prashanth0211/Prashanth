package com.cg.loc1;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Sender {

	public static void main(String[] args) throws Exception {

		Employee emp = new Employee();
		emp.setEmpId(1001);
		emp.setEmpName("Prashanth");
		emp.setEmpSal(5555.22);
		emp.setEmpDesig("Analyst");
		System.out.println(System.identityHashCode(emp));

		File file= new File("D:\\Users\\learning\\Desktop\\test.txt");
		FileOutputStream fos=new FileOutputStream(file);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(emp);
		oos.close();
		fos.close();
		System.out.println("Done... ");
		
		
	}

}
