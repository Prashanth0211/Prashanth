package com.cg;


public class Psn extends Thread{

	
}
