package com.cg.threaddemo.ui;

public class Bow extends Thread {

	public void run() {
		
		System.out.println(Thread.currentThread().getName());
		for (int i = 0; i < 15; i++) {
			System.out.println("Nichenametla");
		}
	}

	public static void main(String[] args) {

		System.out.println(Thread.currentThread().getName());
		Bow bow = new Bow();
		bow.start();
		Bow bow1 = new Bow();
		bow1.start();

		for (int i = 0; i < 15; i++) {
			System.out.println("Prashanth");
		}
       
	}

}
