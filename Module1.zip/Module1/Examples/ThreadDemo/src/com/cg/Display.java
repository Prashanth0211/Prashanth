package com.cg;

public class Display {

	public synchronized void wish(String name) {
		for(int i=0;i<10;i++) {
			System.out.println("hello");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			System.out.println(name);
		}
	}
	
}
