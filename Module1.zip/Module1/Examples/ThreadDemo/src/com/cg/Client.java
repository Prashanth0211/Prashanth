package com.cg;

public class Client {

	public static void main(String[] args) {
		
		Display display=new Display();
		MyThread myThread1=new MyThread(display,"Dhoni");
		MyThread myThread2=new MyThread(display,"Kohli");
		myThread1.start();
		myThread2.start();
		try {
			myThread2.wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
