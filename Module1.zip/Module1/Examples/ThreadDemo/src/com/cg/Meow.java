package com.cg;

public class Meow implements Runnable {

	public static void main(String[] args) {
		Thread thread=new Thread(new Meow());
		thread.run();
		System.out.println(Thread.currentThread().getName());
		for (int i = 0; i < 15; i++) {
			System.out.println("Nichenametla");
		}
	}

	@Override
	public void run() {
	
		System.out.println(Thread.currentThread().getName());
		
		for (int i = 0; i < 15; i++) {
			try {
				Thread.currentThread().sleep(1000);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Prashanth");
		}
	}

}
