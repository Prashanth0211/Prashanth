package com.cg;

@FunctionalInterface
public interface ICalculation {

	public void power(int a, int b);
}
