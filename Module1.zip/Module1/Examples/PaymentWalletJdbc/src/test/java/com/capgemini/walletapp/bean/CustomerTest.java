package com.capgemini.walletapp.bean;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {
	
	Customer cust=new Customer();
	public void testGetAdharNumber() {
		cust.setAadharNumber(12345678);
		assertEquals(12345678, cust.getAadharNumber());
	}
	public void testGetWallet() {
		
	}

	public void testGetCustomerName() {
		cust.setCustomerName("Prashanth");
		assertEquals("Prashanth", cust.getCustomerName());
	}

	public void testGetAddress() {
		cust.setAddress("Gachibowli");
		assertEquals("Gachibowli", cust.getAddress());
	}

	public void testGetPhoneNumber() {
		cust.setPhoneNumber("7660824282");
		assertEquals("7660824282", cust.getPhoneNumber());
		
	}

	public void testGetGender() {
		cust.setGender("male");
		assertEquals("male",cust.getGender());
	}

	public void testGetAge() {
		cust.setAge(22);
		assertEquals(22, cust.getAge());
		
	}

	public void testGetUser_ID() {
		cust.setUser_ID("Prashanth11");
		assertEquals("Prashanth11", cust.getUser_ID());
	}

	public void testGetPassword() {
		cust.setPassword("Prashanth@11");
		assertEquals("Prashanth@11", cust.getPassword());
		
	}

}
