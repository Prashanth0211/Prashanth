package com.capgemini.walletapp.service;

import java.util.List;

import java.util.Map;

import com.capgemini.walletapp.bean.Customer;
import com.capgemini.walletapp.exception.WalletException;

public interface IWalletApplicationService {

	public boolean createAccount(Customer customer);

	public double showBalance();

	public boolean logIn(String user_ID, String password);

	public boolean deposite(double amount);

	public boolean withdraw(double amount);

	public boolean fundTransfer(long receiverAccountNumber, double amount);

	public void printTranscation();

	public boolean validationDetails(Customer customer) throws WalletException;

}
