package com.capgemini.walletapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.capgemini.walletapp.bean.Customer;
import com.capgemini.walletapp.exception.WalletException;
import com.capgemini.walletapp.util.DBUtil;

import jdk.nashorn.internal.ir.Statement;

public class WalletApplicationDAO implements IWalletApplicationDAO {
	Connection con = null;
	public static ResultSet rs1;
	public static ResultSet rs2;
	public static ResultSet rs3;
	public static ResultSet rs4;
	double bal;
	public static String aadhar;
	public static long accNum;

	public WalletApplicationDAO() {// throws TakeCareClinicException {

		try {
			con = DBUtil.getConnect();
		} catch (WalletException e) {

			System.out.println(e.getMessage());
		}
	}

	public boolean createAccount(Customer customer) {
		try {
			String sql = "INSERT INTO Customer1 VALUES(?,?,?,?,?,?,?,?,?)";

			PreparedStatement pstmt = con.prepareStatement(sql);
			System.out.println(customer);
			pstmt.setString(1, customer.getCustomerName());
			pstmt.setLong(2, customer.getAadharNumber());
			pstmt.setString(3, customer.getAddress());

			pstmt.setString(4, customer.getPhoneNumber());
			pstmt.setString(5, customer.getGender());
			pstmt.setString(6, customer.getEmail());
			pstmt.setInt(7, customer.getAge());
			pstmt.setString(8, customer.getUser_ID());
			pstmt.setString(9, customer.getPassword());
			LocalDate date = LocalDate.now();
			String date1 = date.toString();
			String sql1 = "INSERT INTO Wallet1 VALUES(?,?,?,?)";

			PreparedStatement pstmt1 = con.prepareStatement(sql1);
			pstmt1.setLong(1, customer.getWallet().getAccountNumber());
			pstmt1.setDouble(2, customer.getWallet().getInitalBalance());
			pstmt1.setLong(3, customer.getWallet().getAadharNumber());
			pstmt1.setString(4, date1);
			int row1 = pstmt.executeUpdate();
			int row2 = pstmt1.executeUpdate();
			if (row1 > 0 && row2 > 0) {
				System.out.println("Row updated");
			} else {

				System.out.println("Row not updated");

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}

	public boolean logIn(String user_ID, String password) {

		try {

			java.sql.Statement stmt1 = con.createStatement();
			String selectQuery1 = "select * from customer1 where USER_ID='" + user_ID + "' and password ='" + password
					+ "'";

			rs1 = stmt1.executeQuery(selectQuery1);

			if (rs1.next()) {

				aadhar = rs1.getString(2);
				java.sql.Statement stmt2 = con.createStatement();
				String selectQuery2 = "select * from wallet1 where AADHAR_NO=" + aadhar;
				rs2 = stmt2.executeQuery(selectQuery2);
				if (rs2.next()) {
					bal = rs2.getFloat(2);
				}
				return true;

			}

		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}

		return false;
	}

	public double showBalance() {

		return bal;
	}

	public boolean deposite(double amount) {
		try {

			bal += amount;
			String updateQuery = "update wallet1 set INITIAL_BALANCE=" + bal + "where AADHAR_NO=" + aadhar;
			System.out.println(updateQuery);
			java.sql.PreparedStatement stmt = con.prepareStatement(updateQuery);
			int r = stmt.executeUpdate();
			String selectQuery3 = "select * from wallet1 where AADHAR_NO=" + aadhar;
			java.sql.PreparedStatement stmt1 = con.prepareStatement(selectQuery3);

			System.out.println(r);
			rs2 = stmt1.executeQuery();

			if (r == 1) {
				System.out.println("Hii");
				String transaction = "Deposited " + Double.toString(amount);
				String insertQ = "insert into transaction2 values('" + aadhar + "','" + transaction + "')";
				System.out.println(insertQ);
				java.sql.PreparedStatement stmt2 = con.prepareStatement(insertQ);
				stmt2.executeUpdate();
				return true;
			}

		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}

		return false;
	}

	public boolean withdraw(double amount) {
		try {
			if (rs2.next()) {
				System.out.println(1);
				bal = rs2.getDouble(2) - amount;
				String updateQuery = "update wallet1 set INITIAL_BALANCE=" + bal + "where AADHAR_NO=" + aadhar;
				System.out.println(updateQuery);
				String selectQuery3 = "select * from wallet1 where AADHAR_NO=" + aadhar;
				java.sql.PreparedStatement stmt = con.prepareStatement(updateQuery);
				int r = stmt.executeUpdate();
				System.out.println(r);
				rs2 = stmt.executeQuery(selectQuery3);
				if (r == 1) {
					String transaction = "withdrawn " + Double.toString(amount);
					String insertQ = "insert into transaction2 values(" + aadhar + ",'" + transaction + "')";
					java.sql.PreparedStatement stmt2 = con.prepareStatement(insertQ);
					stmt2.executeUpdate();
					return true;
				}

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	public boolean fundTransfer(long receiverAccountNumber, double amount) {
		double Currbal = 0;
		String qry = "select Initial_balance from wallet1 where Account_No=?";
		java.sql.PreparedStatement stmt;
		try {
			stmt = con.prepareStatement(qry);
			stmt.setLong(1, receiverAccountNumber);
			ResultSet resultSet = stmt.executeQuery();
			while (resultSet.next()) {
				Currbal = resultSet.getFloat("initial_balance");

			}
			bal -= amount;
			String updateQuery = "update wallet1 set INITIAL_BALANCE=" + bal + "where AADHAR_NO=" + aadhar;
			
			java.sql.PreparedStatement stmts = con.prepareStatement(updateQuery);
			stmts.executeUpdate();

			String updateQuery2 = "update wallet1 set INITIAL_BALANCE=INITIAL_BALANCE-? where Account_No=?";

			PreparedStatement pstat2 = con.prepareStatement(updateQuery2);
			pstat2.setLong(1, receiverAccountNumber);
			pstat2.setDouble(2, Currbal + amount);
			pstat2.executeUpdate();

			String transaction = aadhar + "Amount of " + amount + " is transferred to " + receiverAccountNumber;
			String insertQ = "insert into transaction2 values(" + aadhar + ",'" + transaction + "')";
			java.sql.PreparedStatement stmt2 = con.prepareStatement(insertQ);
			stmt2.executeUpdate();

		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		return true;
	}

	public void printTranscation() {
		try {
			String select = "select * from transaction2 where aadhar_No =" + aadhar;
			java.sql.PreparedStatement stmt = con.prepareStatement(select);
			rs4 = stmt.executeQuery();
			while (rs4.next()) {
				System.out.println(rs4.getString(2));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}

}
