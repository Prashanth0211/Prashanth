package com.capgemini.walletapp.service;

import com.capgemini.walletapp.bean.Customer;
import com.capgemini.walletapp.dao.IWalletApplicationDAO;
import com.capgemini.walletapp.dao.WalletApplicationDAO;
import com.capgemini.walletapp.exception.IWalletException;
import com.capgemini.walletapp.exception.WalletException;

public class WalletApplicationService implements IWalletApplicationService {

	Customer customer = new Customer();
	IWalletApplicationDAO dao = new WalletApplicationDAO();

	public boolean createAccount(Customer customer) {

		return dao.createAccount(customer);
	}

	public double showBalance() {

		return dao.showBalance();

	}

	public boolean logIn(String user_ID, String password) {
		return dao.logIn(user_ID, password);
	}

	public boolean deposite(double amount) {

		return dao.deposite(amount);
	}

	public boolean withdraw(double amount) {

		return dao.withdraw(amount);
	}

	public boolean fundTransfer(long receiverAccountNumber, double amount) {

		return dao.fundTransfer(receiverAccountNumber, amount);

	}

	public void printTranscation() {

		dao.printTranscation();
	}

	public boolean validationDetails(Customer customer) throws WalletException {
		boolean result = false;

		if (customer.getCustomerName().matches("[A-Z]{1}[a-z]+")) {
			if (customer.getPhoneNumber().matches("[0-9]{10}")) {
				if (customer.getEmail().matches("[a-zA-Z0-9_]*@gmail.com")) {
					if (!(customer.getUser_ID().equals(customer.getPassword()))) {
						if (customer.getUser_ID().matches("[A-Za-z0-9]{4,}")) {
							if (customer.getPassword().length() >= 8) {
								result = true;
							} else
								throw new WalletException(IWalletException.ERROR7);
						} else
							throw new WalletException(IWalletException.ERROR6);
					} else
						throw new WalletException(IWalletException.ERROR5);
				} else
					throw new WalletException(IWalletException.ERROR3);
			} else
				throw new WalletException(IWalletException.ERROR2);
		} else
			throw new WalletException(IWalletException.ERROR1);

		return result;
	}

}
