package com.cg.demosix.ui;

enum Months{Jan(31),Feb(28),Mar(31),Apr(30);
	int day;
	Months(int d){
		this.day=d;
	}
}



public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Months mon=null;
System.out.println(mon.Mar.day);
	}

}
