package com.cg.labassignsevenone.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MyMain {

	public static void getSorted(int ar[]) {

		int n=ar.length;
		String k[]=new String[n];
		for(int i=0;i<n;i++) {
			k[i]=String.valueOf(ar[i]);
			StringBuilder s=new StringBuilder();
			s.append(k[i]);
			s=s.reverse();
			k[i]=s.toString();
		}
		ArrayList<Integer> li=new ArrayList<>();
		for(int i=0;i<n;i++) {
			int x=Integer.parseInt(k[i]);
			li.add(x);
			}
		Collections.sort(li);
		System.out.println(li);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=scr.nextInt();
		int ar[]=new int[n];
		System.out.println("Enter elements in array");
		for(int i=0;i<n;i++) {
			ar[i]=scr.nextInt();
		}
	getSorted(ar);
	}

}
