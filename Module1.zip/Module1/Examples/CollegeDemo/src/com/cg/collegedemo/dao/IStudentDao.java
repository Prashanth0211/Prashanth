package com.cg.collegedemo.dao;

import com.cg.collegedemo.dto.StudentDto;

public interface IStudentDao {

	public String showCollegeName(String city);
	public void addStudentDetails(StudentDto dto);
	public StudentDto viewStudentStatus(int sId);
}
