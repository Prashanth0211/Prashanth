package com.cg.collegedemo.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.collegedemo.dto.StudentDto;

public class StudentDaoImpl implements IStudentDao {

	private static Map<String, String> collegeDetails = null;
	private static Map<Integer, StudentDto> studentDetails = null;

	static {
		collegeDetails = new HashMap<>();
		studentDetails = new HashMap<>();
		collegeDetails.put("Delhi", "IIT-D");
		collegeDetails.put("Hyderabad", "IIIT-H");
		collegeDetails.put("Chennai", "IIT-M");
		collegeDetails.put("Bangalore", "IIS-B");
		collegeDetails.put("Mumbai", "IIT-B");

	}

	public void addStudentDetails(StudentDto dto) {
		studentDetails.put(dto.getStuId(), dto);

	}

	@Override
	public StudentDto viewStudentStatus(int sId) {

		return studentDetails.get(sId);

	}

	@Override
	public String showCollegeName(String city) {

		return collegeDetails.get(city);
	}
}