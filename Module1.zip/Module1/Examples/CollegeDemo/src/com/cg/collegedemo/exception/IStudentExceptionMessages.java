package com.cg.collegedemo.exception;

public interface IStudentExceptionMessages {

	String MESSAGE1="Name should contain only Alphabets";
	String MESSAGE2="PhoneNumber should contain only Numbers";
	String MESSAGE3="Age should be between 1 to 100";
	String MESSAGE4="Email is not valid";
	String MESSAGE5="Please enter date of joining correctly";
}
