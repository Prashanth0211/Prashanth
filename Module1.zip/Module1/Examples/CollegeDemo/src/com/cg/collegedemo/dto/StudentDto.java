package com.cg.collegedemo.dto;

import java.time.LocalDate;

public class StudentDto {

	private int stuId;
	private String studName;
	private String stuPhone;
	private String stuCollege;
	private String stuStatus;
	private String stuEmail;
	private int stuAge;
	private String stuGen;
	private String stuCity;
	private LocalDate doj;

	public int getStuId() {
		return stuId;
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getStuPhone() {
		return stuPhone;
	}

	public String setStuPhone(String stuPhone) {
		return this.stuPhone = stuPhone;
	}

	public String getStuCollege() {
		return stuCollege;
	}

	public void setStuCollege(String stuCollege) {
		this.stuCollege = stuCollege;
	}

	public String getStuStatus() {
		return stuStatus;
	}

	public void setStuStatus(String stuStatus) {
		this.stuStatus = stuStatus;
	}

	public String getStuEmail() {
		return stuEmail;
	}

	public void setStuEmail(String stuEmail) {
		this.stuEmail = stuEmail;
	}

	public int getStuAge() {
		return stuAge;
	}

	public void setStuAge(int stuAge) {
		this.stuAge = stuAge;
	}

	public String getStuGen() {
		return stuGen;
	}

	public void setStuGen(String stuGen) {
		this.stuGen = stuGen;
	}

	public String getStuCity() {
		return stuCity;
	}

	public void setStuCity(String stuCity) {
		this.stuCity = stuCity;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

}
