package com.cg.collegedemo.service;

import com.cg.collegedemo.dao.IStudentDao;
import com.cg.collegedemo.dao.StudentDaoImpl;
import com.cg.collegedemo.dto.StudentDto;
import com.cg.collegedemo.exception.IStudentExceptionMessages;
import com.cg.collegedemo.exception.StudentException;

public class StudentServiceImpl implements IStudentService {

	IStudentDao dao = new StudentDaoImpl();

	@Override
	public StudentDto viewStudentStatus(int sId) {

		return dao.viewStudentStatus(sId);
	}

	public Integer addStudentDetails(StudentDto studentdto) {
		int generateId = (int) (Math.random() * 10000);
		String collegeName = dao.showCollegeName(studentdto.getStuCity());
		if (null != collegeName) {
			studentdto.setStuId(generateId);
			studentdto.setStuCollege(collegeName);
			studentdto.setStuStatus("Approved");
			dao.addStudentDetails(studentdto);
		}
		return generateId;
	}

	@Override
	public boolean validationDetails(StudentDto dto) throws StudentException {
		boolean result = true;

		if (!(dto.getStudName().matches("[a-zA-Z]{1,}"))) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE1);
		}
		if (!(dto.getStuPhone().matches("[0-9]+") && dto.getStuPhone().length() == 10)) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE2);
		}
		if (!(dto.getStuAge() > 1 && dto.getStuAge() < 100)) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE3);
		}
		if (!(dto.getStuEmail().matches("[a-zA-Z0-9_]*@gmail.com"))) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE4);
		}
		
		return result;
	}

}
