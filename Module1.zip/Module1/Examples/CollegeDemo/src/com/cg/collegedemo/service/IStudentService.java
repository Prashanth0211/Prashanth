package com.cg.collegedemo.service;

import java.time.LocalDate;

import com.cg.collegedemo.dto.StudentDto;
import com.cg.collegedemo.exception.StudentException;

public interface IStudentService {

	public boolean validationDetails(StudentDto dto) throws StudentException;

	public Integer addStudentDetails(StudentDto studentdto);

	public StudentDto viewStudentStatus(int sId);

}
