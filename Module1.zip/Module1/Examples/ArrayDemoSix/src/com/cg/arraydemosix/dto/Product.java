package com.cg.arraydemosix.dto;

public class Product implements Comparable<Product> {

	private int proId;
	private String proName;
	private double proPrice;
	
	public int getProId() {
		return proId;
	}
	public void setProId(int proId) {
		this.proId = proId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public double getProPrice() {
		return proPrice;
	}
	public void setProPrice(double proPrice) {
		this.proPrice = proPrice;
	}
	
	@Override
	public String toString() {
		return "Product [proId=" + proId + ", proName=" + proName + ", proPrice=" + proPrice + "]";
	}
	@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		if(this.getProId()>o.getProId()) {
			return 1;
		}else if(this.getProId()<o.getProId()) {
			return -1;
		}
		return 0;
	}
	
	
	
}
