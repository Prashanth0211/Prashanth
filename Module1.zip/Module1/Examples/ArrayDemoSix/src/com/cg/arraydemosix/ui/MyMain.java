package com.cg.arraydemosix.ui;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.cg.arraydemosix.dto.Product;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Product proOne=new Product();
		proOne.setProId(1001);
		proOne.setProName("LG");
		proOne.setProPrice(8888.22);
		
		Product proTwo=new Product();
		proTwo.setProId(1003);
		proTwo.setProName("Tv");
		proTwo.setProPrice(8388.22);
		
		Product proThree=new Product();
		proThree.setProId(1002);
		proThree.setProName("pencil");
		proThree.setProPrice(30);

		Map<Integer, Product> myMap=new HashMap<>();
		
		//myMap.put(1, "ABCD");
		//myMap.put(2, "BCD");
		//myMap.put(3, "Ccd");
		
		//System.out.println(myMap);
		//System.out.println(myMap.keySet());//all keys
		//System.out.println(myMap.get(2));//2 key
		//System.out.println(myMap.values());//all values
		
		//for(Integer keys : myMap.keySet()) {
			//System.out.println("Keys are " +keys+"value is "+myMap.get(keys));
			
		//}
		//System.out.println("--------Iterator");
		//Set myData=myMap.entrySet();//keyset & entryset
		//Iterator it=myData.iterator();
		
		//while(it.hasNext()) {
			//System.out.println(it.next());
		//}
		
		myMap.put(1, proOne);
		myMap.put(2, proTwo);
		myMap.put(3, proThree);
		
		
		for(Integer keys :myMap.keySet()) {
			System.out.println(myMap.get(keys).getProId());
			System.out.println(myMap.get(keys).getProName());
			System.out.println(myMap.get(keys).getProPrice());
		}
		
		System.out.println("----After Sort-----");
		Collection<Product> mySet=myMap.values();
	
		List<Product> myList=new LinkedList<>(mySet);
		
		Collections.sort(myList);
		
		for(Product prod: myList) {
			System.out.println(prod.getProId());
			System.out.println(prod.getProName());
			System.out.println(prod.getProPrice());
		}
	}

}
