package com.cg.labassignthreethree.ui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DateTimeFormatter formate=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the Date in dd/mm/yyyy");
		String date=scr.next();
		LocalDate myDate=LocalDate.parse(date,formate);
		LocalDate today=LocalDate.now();
		Period diff=myDate.until(today);
		System.out.println("Days: "+diff.getDays());
		System.out.println("Months: "+diff.getMonths());
		System.out.println("Years: "+diff.getYears());
	}

}
