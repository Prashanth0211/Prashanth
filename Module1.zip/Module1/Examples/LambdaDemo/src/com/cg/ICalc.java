package com.cg;
@FunctionalInterface
public interface ICalc {

	public void add(int a,int b);
}
