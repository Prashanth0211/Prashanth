package com.cg;

public class Test {

	public static void main(String[] args) {    
		ICalc c=(a,b)-> {                       //ICalc c=(a,b)->a+b;
			System.out.println(a+b);           //int result=c.add(10,20);
			System.out.println("Prashanth");   //System.out.println(result);
		};
		c.add(10, 20);
	}

}
