package com.cg.newdemofour.ui;

import java.util.Scanner;

import com.cg.newdemofour.exception.EmployeeException;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//showAllData(10,0);
	
	//	public static void showAllData(int one,int two) {
			//int a[]= {10,20,30};
			//try {
			//int result=one/two;
			//System.out.println(a[3]);
		//System.out.println(result);
		//}catch(ArithmeticException ex) {
			//System.out.println("Number 2 should not be zero or negative....");
		//}catch(ArrayIndexOutOfBoundsException e) {
			//System.out.println("Index out of bounds...");
		//}catch(Exception w) {
          //  System.out.println("Exception occur....."+w.getMessage());//printing message
            //w.printStackTrace();//developer
		//}
			//finally {
      
			//System.out.println("Always Execute.....");
		//}
		//System.out.println("Other codes....");
		
	//}
	//Employee emp=new Employee();
	//try {
		//emp.getData(10,0);
	//}catch(ArithmeticException ex){
		//System.out.println(ex.getMessage());
	//}
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter age");
		int age=scr.nextInt();
		Employee emp=new Employee();
		try {
			emp.setEmpAge(age);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
             System.out.println(e.getMessage());
		}
}
}

