package com.cg.arraydemothree.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<String> myTreeSet=new TreeSet<>();
		myTreeSet.add("A");
		myTreeSet.add("Z");
		myTreeSet.add("G");
		myTreeSet.add("B");
		myTreeSet.add("C");
		myTreeSet.add("D");
		myTreeSet.add("A");
		
		for(String str:myTreeSet){
			System.out.println(str);
		}
		System.out.println("---------");
		Iterator<String> it=myTreeSet.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
