package com.cg.labassignseventhree.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MyMain {

	public static List<String> removeElements(List<String> lis1,List<String> lis2){
		lis1.removeAll(lis2);
		return lis1;
	}
	public static void main(String[] args) {
		
		List<String> li1=new ArrayList<String>();
		List<String> li2=new ArrayList<String>();
		List<String> li3=new ArrayList<String>();
		
		Scanner scr=new Scanner(System.in);
		int n=scr.nextInt();
		for(int i=0;i<n;i++) {
			li1.add(scr.next());
			
		}
		Scanner scr1=new Scanner(System.in);
		int a=scr1.nextInt();
		for(int i=0;i<a;i++) {
			li2.add(scr.next());
			
		}
		li3=removeElements(li1, li2);
		System.out.println(li3);
	}
}
