package com.cg.labassigntwotwo.ui;

public class MyMain {

	public static void main(String[] args) {
		int numberOne=Integer.parseInt(args[0]);
		
		if(numberOne>0)
		{
			System.out.println("Positive Number");
		}
		else {
			System.out.println("Negative Number");
		}

	}

}
