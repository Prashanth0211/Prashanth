package com.cg;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;

public class Proper {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Properties properties=new Properties();
		properties.load(new FileReader(new File("")));
	}

}
