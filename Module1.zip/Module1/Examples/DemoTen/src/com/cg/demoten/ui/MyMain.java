package com.cg.demoten.ui;

import com.cg.demoten.service.General;
import com.cg.demoten.service.Shift;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shift temp=new General();
		temp.getLogIn();
		temp.getLogOut();
		temp.printAllData();

	}

}
