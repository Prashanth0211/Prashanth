package com.cg.demoten.service;

public class General extends Shift{

	@Override
	public void getLogIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getLogOut() {
		// TODO Auto-generated method stub
		
	}

}
