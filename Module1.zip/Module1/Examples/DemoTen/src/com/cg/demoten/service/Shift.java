package com.cg.demoten.service;

public abstract class Shift {
	
	public abstract void getLogIn();
	public abstract void getLogOut();
	
	public void printAllData() {
		System.out.println("Non-Absrtact method");
	}

}
