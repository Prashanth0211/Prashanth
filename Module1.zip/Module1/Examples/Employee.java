class Employee{
int empSalary;
String empName;


public void getLogin(){
System.out.println("In Employee Method-GETLOGIN");
}
}