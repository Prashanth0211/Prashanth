package com.cg.labassignsevenfour.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter size of array");
		int n = scr.nextInt();
		int[] ar = new int[n];
		for (int i = 0; i < n; i++) {
			ar[i] = scr.nextInt();
		}

		Map<Integer, Integer> m1 = new HashMap<Integer, Integer>();
		m1 = getSquares(ar);
		System.out.println("After applying sqaure");
		System.out.println(m1);
	}

	public static Map getSquares(int ar[]) {
		int n=ar.length;
		int[] sqr=new int[n];
		for (int i = 0; i < n; i++) {
			sqr[i] = ar[i]*ar[i];
		}
		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		for (int i = 0; i < n; i++) {
			m.put(ar[i], sqr[i]);
		}
		return m;
	}
}
