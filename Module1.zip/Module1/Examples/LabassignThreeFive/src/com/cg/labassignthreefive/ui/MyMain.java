package com.cg.labassignthreefive.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DateTimeFormatter formate=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the Date in dd/mm/yyyy");
		String date=scr.next();
		LocalDate myDate=LocalDate.parse(date,formate);
		LocalDate dateOne;
		dateOne=myDate.plusMonths(2);
		dateOne=myDate.plusYears(3);
		System.out.println("Expiry Date: "+dateOne);
	}

}
