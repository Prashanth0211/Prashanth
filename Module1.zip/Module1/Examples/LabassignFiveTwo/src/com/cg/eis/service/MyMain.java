package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Id:");
		int eid=scr.nextInt();
		System.out.println("Enter Name:");
		String ename=scr.next();
		System.out.println("Enter salary:");
		double esal=scr.nextDouble();
		
		Employee emp=new Employee();
		emp.setId(eid);
		emp.setName(ename);
		emp.setSalary(esal);
		
		if(esal>5000 && esal<20000) {
			emp.setDesignation("System Associate");
			emp.setInsuranceScheme("Scheme C");
		}
		else if(esal>=20000 && esal<40000) {
			emp.setDesignation("Programmer");
			emp.setInsuranceScheme("Scheme B");
		}
		else if(esal>=4000) {
			emp.setDesignation("Manager");
			emp.setInsuranceScheme("Scheme A");
		}
		else if(esal<5000) {
			emp.setDesignation("Clerk");
			emp.setInsuranceScheme("No Scheme");
		}
		
		emp.showDetails();
	}
}
