package com.cg.test;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.exception.EmployeeException;
import com.cg.service.EmployeeService;

public class ExceptionCheck {

	EmployeeService employeeService = new EmployeeService();

	@BeforeClass
	public static void setUp() throws Exception {
		System.out.println("Testing Starts");
	}

	@AfterClass
	public static void setDown() throws Exception {
		System.out.println("Testing Ends");
	}

	@Test(expected = EmployeeException.class)
	public void testExceptionInvalid() throws EmployeeException {
		employeeService.setSalary(1000);
		assertEquals(1000, employeeService.getSalary());
	}
}
