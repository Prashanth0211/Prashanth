package com.cg.service;

public interface IEmployeeService {

	public abstract void showDetails();
}
