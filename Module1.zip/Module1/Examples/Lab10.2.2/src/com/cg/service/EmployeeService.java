package com.cg.service;

import com.cg.exception.EmployeeException;

public class EmployeeService implements IEmployeeService {

	int id;
	String name;
	double salary;
	String designation, insuranceScheme;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) throws EmployeeException {
		if (salary < 3000)
			throw new EmployeeException("Your salary is less than 3000");
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}

	@Override
	public void showDetails() {

		System.out.println("Id: " + getId());
		System.out.println("Name: " + getName());
		System.out.println("Salary: " + getSalary());
		System.out.println("Designation: " + getDesignation());
		System.out.println("Insurance Scheme: " + getInsuranceScheme());
	}

}
