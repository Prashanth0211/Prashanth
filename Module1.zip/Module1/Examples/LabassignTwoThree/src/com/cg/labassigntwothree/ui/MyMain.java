package com.cg.labassigntwothree.ui;

public class MyMain {

	public static void main(String[] args) {
		
		Person per=new Person("Prashanth","Nichenametla","Male");
		System.out.println("PersonDetails: ");
		System.out.println("_______________");
		System.out.println("FirstName: "+per.getFirstName());
		System.out.println("LastName: "+per.getLastName());
		System.out.println("Gender: "+per.getGender());
		
	}
	
}
