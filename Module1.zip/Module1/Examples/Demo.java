public class Demo{
public static void main(String args[]){
Employee emp=new Employee();
emp.getLogin();
emp.empName=args[0];
int salary=Integer.parseInt(args[1]);
emp.empSalary=salary;
System.out.println("Salary is "+emp.empSalary+ " Name is " +emp.empName);
System.out.println("Hello World");
}
}