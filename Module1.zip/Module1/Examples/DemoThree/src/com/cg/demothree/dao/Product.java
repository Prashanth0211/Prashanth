package com.cg.demothree.dao;

public class Product {

}
