package com.cg.demothree.service;

public class Product {
public int prodId;
}
