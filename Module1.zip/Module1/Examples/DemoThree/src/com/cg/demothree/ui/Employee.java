package com.cg.demothree.ui;

public class Employee {
	
private int empId;
private String empName;
private double empSal;

public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId=empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName=empName;
}
public double getEmpSalary() {
	return empSal;
}
public void setEmpSalary(double empSal) {
	this.empSal=empSal;
}
}
