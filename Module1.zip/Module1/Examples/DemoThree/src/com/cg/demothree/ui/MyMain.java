package com.cg.demothree.ui;

import com.cg.demothree.service.Product;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee emp=new Employee();
Product prod=new Product();
prod.prodId=1000;
emp.setEmpId(1001);
emp.setEmpName("PSN");
emp.setEmpSalary(9993.12);

System.out.println(emp.getEmpId()+" "+emp.getEmpName()+" "+emp.getEmpSalary());
	}

}
