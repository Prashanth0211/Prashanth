package com.cg.demothree.ui;

public class Product {

}
