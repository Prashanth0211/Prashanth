package com.cg.arraydemofive.ui;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.cg.arraydemofive.dto.Product;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product proOne=new Product();
		proOne.setProdId(1002);
		proOne.setProdName("LG");
		proOne.setProdPrice(1999.99);
		
		Product proTwo=new Product();
		proTwo.setProdId(1001);
		proTwo.setProdName("Tv");
		proTwo.setProdPrice(7999.99);
		
		Product proThree=new Product();
		proThree.setProdId(1003);
		proThree.setProdName("Rice");
		proThree.setProdPrice(80);
		
		List<Product> myList=new LinkedList<>();
		myList.add(proOne);
		myList.add(proTwo);
		myList.add(proThree);
		
		Collections.sort(myList);
		
		for(Product prod:myList) {
			System.out.println("Id is "+prod.getProdId());
			System.out.println("Name is "+prod.getProdName());
			System.out.println("Price is"+prod.getProdPrice());
		}
	}

}
