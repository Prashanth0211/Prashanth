package com.cg.labassignsevenfive.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {

		System.out.println("Enter size of list");
		Scanner scr = new Scanner(System.in);
		int n = scr.nextInt();
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < n; i++) {
			list.add(scr.next());
		}
		Collections.sort(list);
		System.out.println("After Sorting list is");
		for (String str : list) {
			System.out.println(str);
		}
	}

}
