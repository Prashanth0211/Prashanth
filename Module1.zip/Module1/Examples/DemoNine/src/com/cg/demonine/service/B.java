package com.cg.demonine.service;

public class B extends A {
	
	//public B() {
		//super
		//System.out.println("In constuctor B.....");
	//}

	//public B(int a) {
		//super
		//this();//constructor chaining
		//System.out.println("In constuctor B....."+a);
	//}
	public void getData() {
		
		//super.showData();
		System.out.println("In getData B");
	}
}
