package com.cg.demonine.ui;

import com.cg.demonine.service.A;
import com.cg.demonine.service.B;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//B temp=new B();
//temp.getData();
//temp.getData();
//System.out.println(temp.eId);
A temp=new B();
((B)temp).getData();



	}

}
